// Recibe los avisos del celular por un servidor intermedio ntfy (público o propio).
// Solo conexiones salientes: no hace falta IP fija, firewall ni que el celular esté en el mismo WiFi.

const WATCHDOG_MS = 120_000 // ntfy manda un latido cada ~45 s; sin nada en 2 min la conexión se da por muerta

/** Una línea del flujo JSON de ntfy → mensaje, o null (open, keepalive, basura). */
export function parseNtfyLine(line) {
  try {
    const m = JSON.parse(line)
    return m.event === 'message' && typeof m.message === 'string' && m.id ? { id: m.id, time: Number(m.time) || 0, text: m.message } : null
  } catch {
    return null
  }
}

const REASONS = { ENOTFOUND: 'no se encontró el servidor (revisa el nombre y el internet)', ECONNREFUSED: 'el servidor rechazó la conexión', ETIMEDOUT: 'se agotó el tiempo (revisa el internet)' }
function explain(e) {
  if (e.http === 401 || e.http === 403) return 'el servidor rechazó el token: si usas ntfy.sh público, quítalo (botón «Quitar token guardado»)'
  if (e.http === 429) return 'demasiadas conexiones, reintentando'
  if (e.http) return `el servidor respondió ${e.http}`
  if (e.name === 'AbortError') return 'sin señal del servidor, reconectando'
  return REASONS[e.cause?.code] || e.cause?.code || e.message || 'no se pudo conectar'
}

/**
 * `getOptions()` → { enabled, server, topic, token }. `getLast()/setLast()` guardan hasta dónde se leyó, así un
 * reinicio o un corte de internet no pierde avisos (ntfy los guarda 12 h) ni repite los ya dichos.
 */
export function createRelay({ getOptions, getLast, setLast, onMessage, baseDelay = 2000, log = console.error }) {
  let ctrl
  let timer
  let watchdog
  let retry = 0
  let stopped = true
  let current = ''
  let status = { state: 'off' }

  async function handle(m) {
    const last = getLast()
    if (last.seen.includes(m.id)) return
    setLast({ time: Math.max(m.time, last.time), seen: [...last.seen, m.id].slice(-50) })
    try {
      await onMessage(m.text, m.time * 1000)
    } catch (e) {
      log('relay:', e.message)
    }
  }

  async function run() {
    clearTimeout(timer)
    const o = getOptions()
    if (!o?.enabled || !o.topic) return void (status = { state: 'off' })
    const mine = (ctrl = new AbortController())
    status = { state: 'connecting' }
    let delay
    try {
      const since = getLast().time ? Math.max(getLast().time - 1, 1) : '10m'
      const res = await fetch(`${o.server.replace(/\/+$/, '')}/${encodeURIComponent(o.topic)}/json?since=${since}`, {
        headers: o.token ? { Authorization: `Bearer ${o.token}` } : {},
        signal: mine.signal,
      })
      if (!res.ok) throw Object.assign(new Error(`HTTP ${res.status}`), { http: res.status })
      retry = 0
      status = { state: 'connected', since: Date.now() }
      const arm = () => {
        clearTimeout(watchdog)
        watchdog = setTimeout(() => mine.abort(), WATCHDOG_MS)
      }
      arm()
      const dec = new TextDecoder()
      let buf = ''
      for await (const chunk of res.body) {
        arm()
        buf += dec.decode(chunk, { stream: true })
        let i
        while ((i = buf.indexOf('\n')) >= 0) {
          const m = parseNtfyLine(buf.slice(0, i))
          buf = buf.slice(i + 1)
          if (m) await handle(m)
        }
      }
      status = { state: 'connecting' }
    } catch (e) {
      if (stopped || mine !== ctrl) return
      status = { state: 'error', error: explain(e) }
      if (e.http === 401 || e.http === 403) delay = 120_000
    } finally {
      clearTimeout(watchdog)
    }
    if (!stopped && mine === ctrl) timer = setTimeout(run, delay ?? Math.min(baseDelay * 2 ** retry++, 60_000))
  }

  const stop = () => {
    stopped = true
    clearTimeout(timer)
    clearTimeout(watchdog)
    ctrl?.abort()
    ctrl = undefined
    status = { state: 'off' }
  }
  const start = () => {
    stopped = false
    retry = 0
    return run()
  }

  return {
    status: () => status,
    start,
    stop,
    /** Llamar tras cambiar la configuración: reconecta solo si algo de la conexión cambió. */
    sync() {
      const o = getOptions()
      const key = JSON.stringify(o?.enabled ? [o.server, o.topic, o.token] : null)
      if (key === current && !stopped) return
      current = key
      stop()
      if (o?.enabled) start()
    },
  }
}
