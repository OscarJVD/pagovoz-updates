// Registro de eventos del programa (errores, conexión, avisos). Sin nombres ni correos: se enmascaran.
import { appendFileSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { DATA_DIR } from './store.js'

const FILE = join(DATA_DIR, 'events.log')
const MAX_BYTES = 200_000
const clean = (s) => String(s).replace(/[\w.+-]+@[\w.-]+/g, '***').replace(/\s+/g, ' ').slice(0, 200)

export function logEvent(msg, level = 'info') {
  const line = `${new Date().toISOString()}\t${level}\t${clean(msg)}\n`
  if (level === 'error') console.error(clean(msg))
  try {
    if (statSync(FILE, { throwIfNoEntry: false })?.size > MAX_BYTES) writeFileSync(FILE, readFileSync(FILE, 'utf8').split('\n').slice(-500).join('\n'))
    appendFileSync(FILE, line)
  } catch {}
}

export function recentEvents(n = 100) {
  try {
    return readFileSync(FILE, 'utf8').split('\n').filter(Boolean).slice(-n).reverse().map((l) => {
      const [ts, level, ...m] = l.split('\t')
      return { ts: Date.parse(ts), level, msg: m.join(' ') }
    })
  } catch {
    return []
  }
}
