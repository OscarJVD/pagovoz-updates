import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { UI_DEFAULTS } from './branding.js'

export const DATA_DIR = process.env.PAGOVOZ_DATA || join(process.cwd(), 'data')
mkdirSync(join(DATA_DIR, 'cache'), { recursive: true })

export const DEFAULTS = {
  mails: [],
  senders: ['nequi.com.co'],
  requireDkim: true,
  maxAgeMin: 10,
  paused: false,
  rules: { silenceAbove: { enabled: true, amount: 700000 } },
  sources: { venta: true, recibido: true, nequi: true },
  phone: { enabled: true, key: '', packages: ['com.nequi.MobileApp'], relay: { enabled: false, server: 'https://ntfy.sh', topic: '', token: '' } },
  voice: {
    engine: 'edge',
    voice: 'es-CO-SalomeNeural',
    systemVoice: '',
    template: 'Recibiste {monto} {pagador}',
    sayName: true,
    firstNameOnly: true,
    chime: true,
    volume: 100,
  },
  ui: UI_DEFAULTS,
  update: { auto: false, time: '11:00' },
  adminPin: '',
}

const read = (file, fallback) => {
  try {
    return JSON.parse(readFileSync(join(DATA_DIR, file), 'utf8'))
  } catch {
    return fallback
  }
}
const write = (file, value) => {
  const path = join(DATA_DIR, file)
  writeFileSync(`${path}.tmp`, JSON.stringify(value, null, 2), { mode: 0o600 })
  renameSync(`${path}.tmp`, path)
}

const merge = (base, saved) => {
  const out = {}
  for (const [k, v] of Object.entries(base)) {
    out[k] = v && typeof v === 'object' && !Array.isArray(v) ? merge(v, saved?.[k] ?? {}) : (saved?.[k] ?? v)
  }
  return out
}

const saved = read('config.json', {})
let config = merge(DEFAULTS, saved)
// Versión anterior: un solo correo en `mail`.
if (!config.mails.length && saved.mail?.user) {
  const m = saved.mail
  config.mails = [{ id: 'm1', label: '', host: m.host || 'imap.gmail.com', port: m.port || 993, user: m.user, pass: m.pass || '', mailbox: m.mailbox || 'INBOX', enabled: true }]
  write('config.json', config)
}
let history = read('history.json', [])
let state = { seen: [], boxes: {}, ...read('state.json', {}) }
if (state.lastUid && !state.boxes.m1) state.boxes = { ...state.boxes, m1: { lastUid: state.lastUid, uidValidity: state.uidValidity } }

export const getConfig = () => config
export const setConfig = (next) => {
  config = next
  write('config.json', config)
}

export const getHistory = () => history
export const addHistory = (entry) => {
  history.unshift(entry)
  history = history.slice(0, 200)
  write('history.json', history)
  return entry
}
export const saveHistory = () => write('history.json', history)

export const getState = () => state
export const setState = (patch) => {
  state = { ...state, ...patch }
  write('state.json', state)
}

/** Hasta qué correo (UID) se ha leído cada buzón. */
export const getBox = (id) => state.boxes[id] ?? { lastUid: 0, uidValidity: 0 }
export const setBox = (id, patch) => setState({ boxes: { ...state.boxes, [id]: { ...getBox(id), ...patch } } })
