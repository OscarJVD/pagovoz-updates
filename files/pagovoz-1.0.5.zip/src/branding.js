// Marca personalizable: colores, fuentes, logo y favicon. Todo lo que llega del panel se valida aquí.
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

export const FONTS = ['system', 'inter', 'atkinson', 'nunito', 'poppins']
export const SCALES = ['normal', 'large', 'xlarge']
export const RADII = ['square', 'soft', 'round']
export const DENSITIES = ['comfortable', 'compact']
export const DEFAULT_VIDEO_BASE = 'https://oscarjvd.github.io/pagovoz-updates/tutoriales'

const str = (v, max, d) => (typeof v === 'string' ? v.trim().slice(0, max) : d)
const bool = (v, d) => (typeof v === 'boolean' ? v : d)
const pick = (v, list, d) => (list.includes(v) ? v : d)
const color = (v, d) => (typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : d)

export const UI_DEFAULTS = {
  productName: 'PagoVoz',
  businessName: 'Mi negocio',
  logoUrl: '',
  primary: '#7c3aed',
  accent: '#06b6d4',
  theme: 'dark',
  font: 'system',
  customFont: '',
  fontScale: 'normal',
  radius: 'soft',
  density: 'comfortable',
  faviconText: '',
  supportWhatsapp: '',
  supportText: '',
  tutorials: true,
  videoBase: DEFAULT_VIDEO_BASE,
  brandV: 0,
}

export function sanitizeUi(p = {}, b = UI_DEFAULTS) {
  const url = (v, d) => (typeof v === 'string' && /^(https?:\/\/|data:image\/)/i.test(v.trim()) ? v.trim().slice(0, 200_000) : v === '' ? '' : d)
  const base = (v, d) => (typeof v === 'string' && /^https?:\/\/[^\s]+$/i.test(v.trim()) ? v.trim().replace(/\/+$/, '').slice(0, 300) : d)
  return {
    productName: str(p.productName, 40, b.productName) || b.productName,
    businessName: str(p.businessName, 60, b.businessName) || b.businessName,
    logoUrl: url(p.logoUrl, b.logoUrl),
    primary: color(p.primary, b.primary),
    accent: color(p.accent, b.accent),
    theme: pick(p.theme, ['dark', 'light', 'auto'], b.theme),
    font: pick(p.font, FONTS, b.font),
    customFont: typeof p.customFont === 'string' ? (/^[A-Za-z0-9 ]{2,40}$/.test(p.customFont.trim()) ? p.customFont.trim() : '') : b.customFont,
    fontScale: pick(p.fontScale, SCALES, b.fontScale),
    radius: pick(p.radius, RADII, b.radius),
    density: pick(p.density, DENSITIES, b.density),
    faviconText: typeof p.faviconText === 'string' ? Array.from(p.faviconText.trim()).slice(0, 2).join('') : b.faviconText,
    supportWhatsapp: typeof p.supportWhatsapp === 'string' ? p.supportWhatsapp.replace(/\D/g, '').slice(0, 15) : b.supportWhatsapp,
    supportText: str(p.supportText, 120, b.supportText),
    tutorials: bool(p.tutorials, b.tutorials),
    videoBase: base(p.videoBase, b.videoBase),
    brandV: b.brandV, // lo maneja el servidor al subir imágenes
  }
}

// ── Imágenes (logo / favicon) ───────────────────────────────────────────
const TYPES = { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', ico: 'image/x-icon', svg: 'image/svg+xml' }

/** Qué tipo de imagen es, mirando los primeros bytes (no se confía en lo que diga el navegador). */
export function sniffImage(buf) {
  if (buf.length < 12) return null
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png'
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg'
  if (buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') return 'webp'
  if (buf[0] === 0 && buf[1] === 0 && buf[2] === 1 && buf[3] === 0) return 'ico'
  return null
}

export function decodeImage(dataUrl, { allowIco = false, maxBytes = 512 * 1024 } = {}) {
  const m = /^data:image\/[\w.+-]+;base64,([A-Za-z0-9+/=\s]+)$/.exec(String(dataUrl ?? ''))
  if (!m) throw new Error('Imagen inválida')
  const data = Buffer.from(m[1], 'base64')
  if (data.length > maxBytes) throw new Error(`La imagen pesa más de ${Math.round(maxBytes / 1024)} KB`)
  const ext = sniffImage(data)
  if (!ext || (ext === 'ico' && !allowIco)) throw new Error(allowIco ? 'Usa una imagen PNG, JPG, WEBP o ICO' : 'Usa una imagen PNG, JPG o WEBP')
  return { ext, data }
}

export function createBrandStore(dir) {
  const find = (kind) => (existsSync(dir) ? readdirSync(dir).find((f) => f.startsWith(`${kind}.`)) : undefined)
  return {
    has: (kind) => !!find(kind),
    file(kind) {
      const f = find(kind)
      return f ? { path: join(dir, f), type: TYPES[f.split('.').pop()] ?? 'application/octet-stream' } : null
    },
    save(kind, ext, data) {
      mkdirSync(dir, { recursive: true })
      this.remove(kind)
      writeFileSync(join(dir, `${kind}.${ext}`), data)
    },
    remove(kind) {
      const f = find(kind)
      if (f) rmSync(join(dir, f), { force: true })
    },
    read(kind) {
      const f = this.file(kind)
      return f ? { ...f, data: readFileSync(f.path) } : null
    },
  }
}

// ── Favicon generado (cuando no suben uno) ──────────────────────────────
export function readableOn(hex) {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4))
  // Con L > 0.18 el texto oscuro tiene más contraste que el blanco.
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.18 ? '#111827' : '#ffffff'
}

const esc = (s) => s.replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' })[c])
export const initials = (name) => (Array.from(name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map((w) => Array.from(w)[0]).join('') || 'P').join('')).toUpperCase()

export function faviconSvg({ primary, businessName, faviconText }) {
  const text = esc((faviconText || initials(businessName)).slice(0, 8))
  const size = Array.from(text).length > 1 ? 30 : 38
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="${primary}"/><text x="32" y="33" text-anchor="middle" dominant-baseline="central" font-family="system-ui,-apple-system,Segoe UI,sans-serif" font-size="${size}" font-weight="700" fill="${readableOn(primary)}">${text}</text></svg>`
}
