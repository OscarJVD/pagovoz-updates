import { randomBytes, timingSafeEqual } from 'node:crypto'
import { existsSync, readFileSync, statSync } from 'node:fs'
import http from 'node:http'
import { extname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import QRCode from 'qrcode'

import { createBrandStore, decodeImage, faviconSvg, sanitizeUi } from './branding.js'
import { createWatcher, explain, testMail } from './mail.js'
import { logEvent, recentEvents } from './eventlog.js'
import { createMonitor } from './monitor.js'
import { createRelay } from './relay.js'
import { createUpdater } from './updater.js'
import { UPDATE_PUBLIC_KEY } from './update-key.js'
import { isRepeat, lanAddress, normalizePhone, parsePhone, PHONE_BODY } from './phone.js'
import { analyzeMail, buildText, handlePayment, processMail } from './pipeline.js'
import { DATA_DIR, getConfig, getHistory, getState, setConfig, setState } from './store.js'
import { enqueue, isBusy, listVoices, pruneCache, speak } from './voice.js'

const PORT = Number(process.env.PORT) || 4747
// Escucha en la red local para recibir los avisos del celular; el panel solo responde al propio equipo.
const HOST = process.env.HOST || '0.0.0.0'
const PUBLIC = fileURLToPath(new URL('../public/', import.meta.url))
const brand = createBrandStore(join(DATA_DIR, 'brand'))
const UPDATE_URL = process.env.PAGOVOZ_UPDATE_URL || 'https://raw.githubusercontent.com/OscarJVD/pagovoz-updates/main'

const watcher = createWatcher(processMail)

// Solo reinicia sola si hay algo que vuelva a abrirla (run-loop.bat en Windows, systemd en la Raspberry).
const updater = createUpdater({
  log: (...a) => logEvent(a.join(' '), 'error'),
  root: fileURLToPath(new URL('..', import.meta.url)),
  dataDir: DATA_DIR,
  baseUrl: UPDATE_URL,
  freshManifestUrl: process.env.PAGOVOZ_UPDATE_URL ? undefined : 'https://api.github.com/repos/OscarJVD/pagovoz-updates/contents/latest.json',
  publicKey: UPDATE_PUBLIC_KEY,
  getSettings: () => getConfig().update,
  isBusy,
  supervised: process.env.PAGOVOZ_SUPERVISED === '1',
})

const newKey = () => randomBytes(9).toString('base64url')
const newTopic = () => `pv-${randomBytes(16).toString('base64url')}`
{
  const p = getConfig().phone
  if (!p.key || !p.relay.topic) setConfig({ ...getConfig(), phone: { ...p, key: p.key || newKey(), relay: { ...p.relay, topic: p.relay.topic || newTopic() } } })
}

// ── Validación de lo que llega del panel ────────────────────────────────
const str = (v, max, d) => (typeof v === 'string' ? v.trim().slice(0, max) : d)
const num = (v, min, max, d) => (Number.isFinite(Number(v)) && v !== '' && v !== null ? Math.min(max, Math.max(min, Math.round(Number(v)))) : d)
const bool = (v, d) => (typeof v === 'boolean' ? v : d)
const color = (v, d) => (/^#[0-9a-f]{6}$/i.test(v) ? v : d)
const url = (v, d) => (typeof v === 'string' && /^(https?:\/\/|data:image\/)/i.test(v.trim()) ? v.trim().slice(0, 200_000) : v === '' ? '' : d)

function sanitizeVoice(p = {}, b) {
  return {
    engine: p.engine === 'system' ? 'system' : p.engine === 'edge' ? 'edge' : b.engine,
    voice: /^[a-z]{2}-[A-Z]{2}-\w+$/.test(p.voice) ? p.voice : b.voice,
    systemVoice: str(p.systemVoice, 60, b.systemVoice),
    template: str(p.template, 200, b.template) || b.template,
    sayMethod: bool(p.sayMethod, b.sayMethod),
    methodLabels: Object.fromEntries(['llave', 'qr', 'nequi'].map((k) => [k, str(p.methodLabels?.[k], 30, b.methodLabels[k]) || b.methodLabels[k]])),
    sayName: bool(p.sayName, b.sayName),
    firstNameOnly: bool(p.firstNameOnly, b.firstNameOnly),
    chime: bool(p.chime, b.chime),
    volume: num(p.volume, 0, 100, b.volume),
  }
}

function sanitizeMails(list, current) {
  if (!Array.isArray(list)) return current
  const used = new Set()
  return list.slice(0, 10).map((m) => {
    let old = current.find((x) => x.id === m?.id)
    if (old && used.has(old.id)) old = undefined
    const id = old?.id ?? randomBytes(4).toString('hex')
    used.add(id)
    const user = str(m?.user, 200, old?.user ?? '')
    return {
      id,
      label: str(m?.label, 40, old?.label ?? ''),
      host: str(m?.host, 100, old?.host ?? '') || 'imap.gmail.com',
      port: num(m?.port, 1, 65535, old?.port ?? 993),
      user,
      // Contraseña vacía = conservar la guardada, salvo que hayan cambiado el correo.
      pass: m?.pass ? String(m.pass).replace(/\s/g, '').slice(0, 200) : old && old.user === user ? old.pass : '',
      mailbox: str(m?.mailbox, 100, old?.mailbox ?? '') || 'INBOX',
      enabled: bool(m?.enabled, old?.enabled ?? true),
    }
  })
}

function applyPatch(c, p) {
  const senders = (Array.isArray(p.senders) ? p.senders : String(p.senders ?? '').split(','))
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean)
  return {
    mails: sanitizeMails(p.mails, c.mails),
    senders: senders.length ? senders : c.senders,
    requireDkim: bool(p.requireDkim, c.requireDkim),
    maxAgeMin: num(p.maxAgeMin, 1, 1440, c.maxAgeMin),
    paused: bool(p.paused, c.paused),
    rules: {
      silenceAbove: {
        enabled: bool(p.rules?.silenceAbove?.enabled, c.rules.silenceAbove.enabled),
        amount: num(p.rules?.silenceAbove?.amount, 1, 1e9, c.rules.silenceAbove.amount),
      },
    },
    sources: { venta: bool(p.sources?.venta, c.sources.venta), recibido: bool(p.sources?.recibido, c.sources.recibido), nequi: bool(p.sources?.nequi, c.sources.nequi) },
    phone: {
      enabled: bool(p.phone?.enabled, c.phone.enabled),
      key: c.phone.key,
      relay: {
        enabled: bool(p.phone?.relay?.enabled, c.phone.relay.enabled),
        server: /^https?:\/\/[^\s/]+\S*$/i.test(p.phone?.relay?.server ?? '') ? p.phone.relay.server.trim().replace(/\/+$/, '') : c.phone.relay.server,
        topic: /^[\w-]{16,64}$/.test(p.phone?.relay?.topic ?? '') ? p.phone.relay.topic : c.phone.relay.topic,
        token: p.phone?.relay?.clearToken === true ? '' : p.phone?.relay?.token ? String(p.phone.relay.token).trim().slice(0, 200) : c.phone.relay.token,
      },
      packages: p.phone?.packages === undefined ? c.phone.packages : (Array.isArray(p.phone.packages) ? p.phone.packages : String(p.phone.packages).split(',')).map((s) => String(s).trim()).filter((s) => /^[\w.]{3,100}$/.test(s)),
    },
    voice: sanitizeVoice(p.voice, c.voice),
    ui: sanitizeUi(p.ui, c.ui),
    monitor: {
      enabled: bool(p.monitor?.enabled, c.monitor.enabled),
      url: /^https:\/\/[^\s]+$/i.test(p.monitor?.url ?? '') ? p.monitor.url.trim().replace(/\/+$/, '').slice(0, 200) : c.monitor.url,
      id: typeof p.monitor?.id === 'string' ? p.monitor.id.trim().toLowerCase().slice(0, 40) : c.monitor.id,
      token: p.monitor?.token ? String(p.monitor.token).trim().slice(0, 100) : c.monitor.token,
      details: bool(p.monitor?.details, c.monitor.details),
    },
    update: {
      auto: bool(p.update?.auto, c.update.auto),
      time: /^([01]\d|2[0-3]):[0-5]\d$/.test(p.update?.time ?? '') ? p.update.time : c.update.time,
    },
    adminPin: typeof p.adminPin === 'string' ? p.adminPin.trim().slice(0, 40) : c.adminPin,
  }
}

const uiView = (ui) => ({ ...ui, hasLogo: brand.has('logo'), hasFavicon: brand.has('favicon') })
const view = (c) => ({ ...c, ui: uiView(c.ui), mails: c.mails.map((m) => ({ ...m, pass: '', hasPass: !!m.pass })), phone: { ...c.phone, key: undefined, relay: { ...c.phone.relay, token: '', hasToken: !!c.phone.relay.token } }, monitor: { ...c.monitor, token: '', hasToken: !!c.monitor.token }, adminPin: undefined, hasPin: !!c.adminPin })
const usable = (a) => a.enabled && a.user && a.pass

/** Resumen del estado de todos los correos para la etiqueta de arriba del panel. */
function mailStatus() {
  const per = watcher.status()
  const active = getConfig().mails.filter(usable)
  if (!active.length) return { state: 'unconfigured', accounts: per }
  const bad = active.find((a) => per[a.id]?.state === 'error')
  const state = bad ? 'error' : active.every((a) => per[a.id]?.state === 'connected') ? 'connected' : 'connecting'
  return { state, error: bad ? `${bad.label || bad.user}: ${per[bad.id].error}` : undefined, accounts: per }
}

// ── Acceso con PIN opcional ─────────────────────────────────────────────
const sessions = new Set()
const fails = new Map()
const cookieOf = (req) => /(?:^|;\s*)pv_sid=([a-f0-9]+)/.exec(req.headers.cookie ?? '')?.[1]
const authed = (req) => !getConfig().adminPin || sessions.has(cookieOf(req))
const same = (a, b) => a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b))

class HttpError extends Error {
  constructor(status, message) {
    super(message)
    this.status = status
  }
}

// ── Avisos del celular (MacroDroid) ─────────────────────────────────────
const phoneLog = []
const phoneHits = []
const logPhone = (entry) => {
  phoneLog.unshift({ ts: Date.now(), ...entry })
  phoneLog.length = Math.min(phoneLog.length, 20)
  return entry
}
const phoneUrl = (c) => `http://${lanAddress()}:${PORT}/api/phone?key=${c.phone.key}`

/** Un aviso del celular, llegue por WiFi o por la nube: mismas reglas para los dos. */
function processPhone(raw, via, ts = Date.now()) {
  const c = getConfig()
  const n = normalizePhone(raw.slice(0, 4000))
  const shown = { via, app: n.app, title: n.title, text: n.text.slice(0, 200) }
  if (!c.phone.packages.includes(n.app)) {
    return logPhone({ ...shown, result: `ignorado: la app ${n.app || '(vacía)'} no está en la lista permitida` })
  }
  const pay = parsePhone(n)
  if (!pay) return logPhone({ ...shown, result: 'ignorado: no es un "te envió"' })
  if (isRepeat(n)) return logPhone({ ...shown, result: 'repetido: ya había sonado' })
  const a = { id: '', date: n.at ?? ts, from: n.app, auth: { ok: true, why: `celular (${via})` }, pay, route: `celular:${via}` }
  const r = handlePayment(a, 'celular')
  return logPhone({ ...shown, result: r.action === 'speak' ? `sonó: "${r.entry.text}"` : `no sonó: ${r.reason}` })
}

function receivePhone(raw, key) {
  const c = getConfig()
  const now = Date.now()
  while (phoneHits.length && now - phoneHits[0] > 60_000) phoneHits.shift()
  if (phoneHits.push(now) > 60) throw new HttpError(429, 'Demasiados avisos')
  if (!c.phone.enabled) throw new HttpError(503, 'Avisos del celular apagados')
  if (!same(key, c.phone.key)) throw new HttpError(401, 'Clave incorrecta')
  return processPhone(raw, 'wifi')
}

const relay = createRelay({
  log: (...a) => logEvent(a.join(' '), 'error'),
  getOptions: () => {
    const p = getConfig().phone
    return { enabled: p.enabled && p.relay.enabled, ...p.relay }
  },
  getLast: () => getState().relayLast ?? { time: 0, seen: [] },
  setLast: (v) => setState({ relayLast: v }),
  onMessage: (text, ts) => processPhone(text, 'nube', ts),
})
const configSnapshot = () => {
  const v = view(getConfig())
  return {
    mails: v.mails.map(({ id, label, host, port, user, mailbox, enabled, hasPass }) => ({ id, label, host, port, user, mailbox, enabled, hasPass })),
    senders: v.senders, requireDkim: v.requireDkim, maxAgeMin: v.maxAgeMin, paused: v.paused, rules: v.rules, sources: v.sources,
    phone: { enabled: v.phone.enabled, packages: v.phone.packages, relay: { enabled: v.phone.relay.enabled, server: v.phone.relay.server, hasToken: v.phone.relay.hasToken } },
    voice: v.voice,
    ui: Object.fromEntries(Object.entries(v.ui).filter(([k, x]) => !['logoUrl', 'hasLogo', 'hasFavicon', 'brandV'].includes(k) && typeof x !== 'object')),
    update: v.update, monitor: { details: v.monitor.details }, hasPin: v.hasPin,
  }
}
// Desde el monitor no se cambian los datos de conexión al propio monitor (si no, el PC quedaría incomunicado).
function remoteConfig(patch) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new Error('configuración inválida')
  const p = structuredClone(patch)
  if (p.monitor) p.monitor = { details: p.monitor.details }
  if (p.ui) delete p.ui.logoUrl
  const before = getConfig()
  setConfig(applyPatch(before, p))
  watcher.sync()
  relay.sync()
  logEvent(`configuración cambiada desde el monitor: ${Object.keys(p).join(', ')}`)
  return 'hecho'
}
const detailsSnapshot = () => ({
  days: Object.entries(getState().daily ?? {}).sort().slice(-14).map(([date, x]) => ({ date, ...x })),
  recent: getHistory().filter((h) => h.status === 'spoken' && h.source !== 'prueba' && h.amount > 0).slice(0, 15).map((h) => ({ ts: h.ts, amount: h.amount, medio: h.method || 'otro', route: h.route })),
})
const COMMANDS = {
  clearRelayToken: () => setConfig({ ...getConfig(), phone: { ...getConfig().phone, relay: { ...getConfig().phone.relay, token: '' } } }),
  enablePhone: () => setConfig({ ...getConfig(), phone: { ...getConfig().phone, enabled: true, relay: { ...getConfig().phone.relay, enabled: true } } }),
  resume: () => setConfig({ ...getConfig(), paused: false }),
  detailsOn: () => setConfig({ ...getConfig(), monitor: { ...getConfig().monitor, details: true } }),
  detailsOff: () => setConfig({ ...getConfig(), monitor: { ...getConfig().monitor, details: false } }),
  update: async () => {
    await updater.check()
    if (!updater.status().available) return 'ya estaba al día'
    await updater.apply()
  },
}
const monitor = createMonitor({
  log: (...a) => logEvent(a.join(' '), 'error'),
  getConfig,
  onCommands: async (list) => {
    const out = []
    const items = list.map((c) => (typeof c === 'string' ? { cmd: c } : c)).filter((c) => c?.cmd === 'config' || COMMANDS[c?.cmd])
    for (const { cmd, patch } of items.sort((a, b) => (a.cmd === 'update') - (b.cmd === 'update'))) {
      logEvent(`orden remota: ${cmd}`)
      try { out.push({ cmd, ok: true, msg: (cmd === 'config' ? remoteConfig(patch) : await COMMANDS[cmd]()) ?? 'hecho' }) } catch (e) { logEvent(`orden remota ${cmd} falló: ${e.message}`, 'error'); out.push({ cmd, ok: false, msg: String(e.message).slice(0, 100) }) }
    }
    return out
  },
  snapshot: () => {
    const accounts = Object.values(watcher.status())
    const day = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Bogota' })
    const st = getState().stats?.date === day ? getState().stats : { date: day, routes: {}, spoken: 0, ignored: 0, error: 0 }
    const u = updater.status()
    return {
      v: u.current,
      uptime: Math.round(process.uptime()),
      paused: getConfig().paused,
      mail: { total: accounts.length, connected: accounts.filter((a) => a.state === 'connected').length, errors: accounts.filter((a) => a.state === 'error').map((a) => String(a.error ?? '').replace(/[\w.+-]+@[\w.-]+/g, '***').slice(0, 80)) },
      relay: getConfig().phone.enabled && getConfig().phone.relay.enabled ? relay.status().state : 'off',
      today: st,
      lastPayment: getHistory().find((h) => h.status === 'spoken')?.ts ?? null,
      update: u.available ? u.latest.version : '',
      events: recentEvents(25).map((e) => ({ ts: e.ts, level: e.level, msg: e.msg })),
      config: configSnapshot(),
      ...(getConfig().monitor.details ? { details: detailsSnapshot() } : {}),
    }
  },
})
const relayUrl = (c) => `${c.phone.relay.server}/${c.phone.relay.topic}`

// ── Rutas ───────────────────────────────────────────────────────────────
const routes = {
  'GET /api/public': () => ({ ui: uiView(getConfig().ui), needsLogin: !!getConfig().adminPin }),

  'POST /api/brand/upload': (body) => {
    const kind = body.kind === 'favicon' ? 'favicon' : body.kind === 'logo' ? 'logo' : null
    if (!kind) throw new HttpError(400, 'Tipo de imagen inválido')
    let img
    try {
      img = decodeImage(body.dataUrl, { allowIco: kind === 'favicon' })
    } catch (e) {
      throw new HttpError(400, e.message)
    }
    brand.save(kind, img.ext, img.data)
    const c = getConfig()
    setConfig({ ...c, ui: { ...c.ui, brandV: c.ui.brandV + 1 } })
    return { ok: true }
  },

  'POST /api/brand/remove': (body) => {
    if (!['logo', 'favicon'].includes(body.kind)) throw new HttpError(400, 'Tipo de imagen inválido')
    brand.remove(body.kind)
    const c = getConfig()
    setConfig({ ...c, ui: { ...c.ui, brandV: c.ui.brandV + 1 } })
    return { ok: true }
  },

  'POST /api/login': (body, req, res) => {
    const ip = req.socket.remoteAddress
    const f = fails.get(ip) ?? { n: 0, at: Date.now() }
    if (Date.now() - f.at > 60_000) Object.assign(f, { n: 0, at: Date.now() })
    if (f.n >= 5) throw new HttpError(429, 'Demasiados intentos, espera un minuto')
    const pin = getConfig().adminPin
    if (!pin || !same(String(body.pin ?? ''), pin)) {
      fails.set(ip, { ...f, n: f.n + 1 })
      throw new HttpError(401, 'PIN incorrecto')
    }
    const sid = randomBytes(24).toString('hex')
    sessions.add(sid)
    res.setHeader('Set-Cookie', `pv_sid=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000`)
    return { ok: true }
  },

  'GET /api/state': () => ({ config: view(getConfig()), status: mailStatus(), history: getHistory().slice(0, 60), platform: process.platform }),

  'GET /api/voices': () => listVoices(),

  'GET /api/monitor': () => ({ ...monitor.status(), configured: !!(getConfig().monitor.id && getConfig().monitor.token) }),
  'POST /api/monitor/test': async () => {
    await monitor.beatNow()
    return { ...monitor.status(), configured: !!(getConfig().monitor.id && getConfig().monitor.token) }
  },

  'GET /api/events': () => ({ events: recentEvents(150) }),

  'GET /api/update': () => updater.status(),
  'POST /api/update/check': () => updater.check(),
  'POST /api/update/apply': async () => {
    try {
      return await updater.apply()
    } catch (e) {
      throw new HttpError(400, e.message)
    }
  },

  'GET /api/phone/setup': async () => {
    const c = getConfig()
    const cloud = c.phone.enabled && c.phone.relay.enabled
    const qr = (t) => QRCode.toString(t, { type: 'svg', margin: 1, errorCorrectionLevel: 'L' })
    // Las dos vías conviven siempre: Internet solo está activa si se enciende; WiFi funciona siempre.
    const wifi = phoneUrl(c)
    const net = relayUrl(c)
    return { cloud, hasToken: !!c.phone.relay.token, relay: relay.status(), cloudUrl: net, cloudQr: await qr(net), wifiUrl: wifi, wifiQr: await qr(wifi), body: PHONE_BODY, bodyQr: await qr(PHONE_BODY), log: phoneLog, packages: c.phone.packages, enabled: c.phone.enabled }
  },

  'POST /api/phone/new-topic': () => {
    const c = getConfig()
    setConfig({ ...c, phone: { ...c.phone, relay: { ...c.phone.relay, topic: newTopic() } } })
    relay.sync()
    return { ok: true }
  },

  'POST /api/phone/new-key': () => {
    const c = getConfig()
    setConfig({ ...c, phone: { ...c.phone, key: newKey() } })
    return { ok: true }
  },

  'POST /api/phone/test': () => {
    const c = getConfig()
    return processPhone(`${c.phone.packages[0] ?? ''}\n${Date.now()}\nEnvío\nPRUEBA CELULAR te envió 1.500, ¡lo mejor!`, 'prueba')
  },

  'PUT /api/config': async (body) => {
    const before = getConfig()
    const next = applyPatch(before, body)
    setConfig(next)
    watcher.sync()
    relay.sync()
    return { ok: true, config: view(next) }
  },

  'POST /api/mail/test': async (body) => {
    const c = getConfig()
    const m = sanitizeMails([body.account], c.mails)[0]
    if (!m.user || !m.pass) throw new HttpError(400, 'Escribe el correo y la contraseña de aplicación')
    try {
      const r = await testMail(m, c.senders)
      return { ok: true, message: `Conexión correcta. ${r.total} correos en el buzón, ${r.fromSender} de ${c.senders[0]}.` }
    } catch (e) {
      throw new HttpError(400, explain(e))
    }
  },

  'POST /api/pause': (body) => {
    const c = getConfig()
    setConfig({ ...c, paused: !!body.paused })
    return { ok: true }
  },

  'POST /api/voice/test': async (body) => {
    const c = getConfig()
    const v = sanitizeVoice(body.voice, c.voice)
    const sample = { amount: num(body.amount, 1, 999_999_999, 20000), payer: str(body.payer, 60, 'ANA GOMEZ'), method: ['llave', 'qr', 'nequi'].includes(body.method) ? body.method : 'llave' }
    const text = buildText(v, sample)
    await enqueue(() => speak(v, text))
    return { ok: true, text }
  },

  'POST /api/test/simulate': (body) => {
    const amount = num(body.amount, 1, 999_999_999, 20000)
    const a = { id: '', date: Date.now(), from: 'prueba', auth: { ok: true, why: 'simulado' }, pay: { amount, payer: str(body.payer, 60, 'PRUEBA'), approved: true, method: ['llave', 'qr', 'nequi'].includes(body.method) ? body.method : 'llave' } }
    const r = handlePayment(a, 'prueba')
    return { ok: true, action: r.action, reason: r.reason, text: r.entry?.text }
  },

  'POST /api/test/last-email': async (body) => {
    const c = getConfig()
    const accounts = c.mails.filter(usable)
    if (!accounts.length) throw new HttpError(400, 'Configura primero un correo')
    const found = []
    const errors = []
    for (const acct of accounts) {
      try {
        const { last } = await testMail(acct, c.senders, { lastN: 5 })
        for (const source of last) found.push({ source, name: acct.label || acct.user })
      } catch (e) {
        errors.push(`${acct.label || acct.user}: ${explain(e)}`)
      }
    }
    if (!found.length) throw new HttpError(errors.length ? 400 : 404, errors.join(' · ') || `No hay correos de ${c.senders.join(', ')} en el buzón`)
    const analyzed = []
    for (const f of found) analyzed.push({ ...(await analyzeMail(f.source, c)), account: f.name })
    analyzed.sort((x, y) => y.date - x.date)
    const results = []
    let spoke = false
    for (const a of analyzed) {
      // Solo el pago más reciente puede sonar, y solo si se pidió.
      const live = body.speak && !spoke && !!a.pay
      spoke ||= live
      const d = a.pay ? handlePayment(a, 'último correo', { ignoreAge: true, dryRun: !live }) : { action: 'skip' }
      results.push({ cuenta: a.account, from: a.from, subject: a.subject, date: a.date, verificacion: a.auth, pago: a.pay, decision: d.action, motivo: d.reason, texto: a.pay ? buildText(c.voice, a.pay) : null })
    }
    return { ok: true, results }
  },
}

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.woff2': 'font/woff2', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8' }
// El panel solo carga código propio; imágenes y videos pueden venir de cualquier https (logo y tutoriales configurables).
const CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; media-src 'self' https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"

/** Archivos de public/ (nada fuera de esa carpeta, solo tipos conocidos). */
function serveStatic(path, res) {
  let rel
  try {
    rel = decodeURIComponent(path === '/' ? '/index.html' : path)
  } catch {
    return false
  }
  if (!/^\/[\w.\-/]+$/.test(rel) || rel.includes('..')) return false
  const file = join(PUBLIC, rel)
  if (!file.startsWith(PUBLIC) || !MIME[extname(file)] || !existsSync(file) || !statSync(file).isFile()) return false
  res.writeHead(200, {
    'Content-Type': MIME[extname(file)],
    'Cache-Control': rel.startsWith('/fonts/') ? 'public, max-age=31536000, immutable' : 'no-cache',
    'X-Content-Type-Options': 'nosniff',
    ...(file.endsWith('.html') && { 'Content-Security-Policy': CSP, 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer' }),
  })
  res.end(readFileSync(file))
  return true
}

/** Logo y favicon de la marca; si no hay favicon subido se genera con las iniciales y el color. */
function serveBrand(path, res) {
  const kind = path === '/brand/logo' ? 'logo' : 'favicon'
  const f = brand.read(kind)
  const headers = { 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; sandbox" }
  if (f) {
    res.writeHead(200, { ...headers, 'Content-Type': f.type })
    return res.end(f.data)
  }
  if (kind === 'logo') {
    res.writeHead(404, headers)
    return res.end()
  }
  res.writeHead(200, { ...headers, 'Content-Type': 'image/svg+xml' })
  res.end(faviconSvg(getConfig().ui))
}

http
  .createServer(async (req, res) => {
    const path = new URL(req.url, 'http://x').pathname
    const send = (status, data, type = 'application/json') => {
      res.writeHead(status, { 'Content-Type': `${type}; charset=utf-8`, 'Cache-Control': 'no-store' })
      res.end(type === 'application/json' ? JSON.stringify(data) : data)
    }
    try {
      if (req.method === 'POST' && path === '/api/phone') {
        let raw = ''
        for await (const chunk of req) if ((raw += chunk).length > 8000) throw new HttpError(413, 'Cuerpo demasiado grande')
        const key = new URL(req.url, 'http://x').searchParams.get('key') ?? req.headers['x-pagovoz-key'] ?? ''
        return send(200, { ok: true, ...receivePhone(raw, String(key)) })
      }
      // Anti DNS-rebinding: una web ajena no puede hacerse pasar por este equipo con otro nombre.
      const host = String(req.headers.host ?? '').replace(/:\d+$/, '').toLowerCase()
      if (!['localhost', '127.0.0.1', '[::1]', lanAddress()].includes(host)) throw new HttpError(403, 'Dirección no permitida: abre el panel desde http://localhost:' + PORT)
      // Desde otros equipos de la red solo se aceptan los avisos del celular.
      const local = ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress)
      if (!local && !getConfig().adminPin) return send(403, { error: 'El panel solo se abre en este equipo (o pon un PIN)' })
      if (req.method === 'GET' && (path === '/brand/logo' || path === '/brand/favicon' || path === '/favicon.ico')) return serveBrand(path === '/favicon.ico' ? '/brand/favicon' : path, res)
      if (req.method === 'GET' && !path.startsWith('/api/') && serveStatic(path, res)) return
      const route = routes[`${req.method} ${path}`]
      if (!route) return send(404, { error: 'No encontrado' })
      if (req.method !== 'GET') {
        const origin = req.headers.origin
        if (origin && new URL(origin).host !== req.headers.host) throw new HttpError(403, 'Origen no permitido')
      }
      if (path !== '/api/public' && path !== '/api/login' && !authed(req)) throw new HttpError(401, 'Inicia sesión')
      let body = {}
      if (req.method !== 'GET') {
        let raw = ''
        for await (const chunk of req) if ((raw += chunk).length > (path === '/api/brand/upload' ? 1_000_000 : 300_000)) throw new HttpError(413, 'Cuerpo demasiado grande')
        body = raw ? JSON.parse(raw) : {}
      }
      send(200, await route(body, req, res))
    } catch (e) {
      send(e.status ?? 500, { error: e instanceof SyntaxError ? 'JSON inválido' : e.message })
    }
  })
  .listen(PORT, HOST, () => {
    console.log(`PagoVoz en http://localhost:${PORT} · celular: ${phoneUrl(getConfig()).replace(/key=.*/, 'key=…')}`)
    pruneCache()
    watcher.sync()
    relay.sync()
    updater.start()
    logEvent('PagoVoz iniciado')
    monitor.start()
    setTimeout(() => updater.markHealthy(), 45_000).unref()
  })

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => (relay.stop(), monitor.stop(), watcher.stop().finally(() => process.exit(0))))
