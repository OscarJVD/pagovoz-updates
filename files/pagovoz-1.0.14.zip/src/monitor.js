// Latido hacia el monitor central: cada 5 min avisa que este negocio está vivo y cómo le va.
// No envía nombres, montos, correos ni claves: solo estado y conteos por ruta.
const EVERY_MS = 5 * 60_000

export const DEFAULT_MONITOR_URL = 'https://pagovoz-monitor.vercel.app'

export function createMonitor({ getConfig, snapshot, log = console.error }) {
  let timer
  let status = { state: 'off' }

  async function beat() {
    const m = getConfig().monitor
    if (!m?.enabled || !m.id || !m.token || !m.url) return void (status = { state: 'off' })
    try {
      const res = await fetch(`${m.url.replace(/\/+$/, '')}/api/beat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${m.token}` },
        body: JSON.stringify({ id: m.id, ...snapshot() }),
        signal: AbortSignal.timeout(15_000),
      })
      if (!res.ok) throw new Error(res.status === 401 ? 'credenciales rechazadas' : `respuesta ${res.status}`)
      status = { state: 'ok', at: Date.now() }
    } catch (e) {
      status = { state: 'error', error: e.message, at: status.at, tried: Date.now() }
      log('monitor:', e.message)
    }
  }

  return {
    status: () => status,
    beatNow: beat,
    start() {
      clearInterval(timer)
      setTimeout(beat, 20_000).unref()
      timer = setInterval(beat, EVERY_MS)
      timer.unref()
    },
    stop: () => clearInterval(timer),
  }
}
