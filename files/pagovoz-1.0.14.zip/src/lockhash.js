import { createHash } from 'node:crypto'

/** Huella de las dependencias: ignora la entrada de la propia app, cuya versión cambia en cada publicación. */
export function lockHash(text) {
  const { '': _app, ...deps } = JSON.parse(text).packages ?? {}
  return createHash('sha256').update(JSON.stringify(deps)).digest('hex')
}
