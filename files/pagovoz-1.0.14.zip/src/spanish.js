const SMALL = ['cero', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve', 'diez', 'once', 'doce', 'trece', 'catorce', 'quince', 'dieciséis', 'diecisiete', 'dieciocho', 'diecinueve', 'veinte', 'veintiuno', 'veintidós', 'veintitrés', 'veinticuatro', 'veinticinco', 'veintiséis', 'veintisiete', 'veintiocho', 'veintinueve']
const TENS = ['', '', '', 'treinta', 'cuarenta', 'cincuenta', 'sesenta', 'setenta', 'ochenta', 'noventa']
const HUNDREDS = ['', 'ciento', 'doscientos', 'trescientos', 'cuatrocientos', 'quinientos', 'seiscientos', 'setecientos', 'ochocientos', 'novecientos']

// Siempre antes de un sustantivo masculino: "un peso", "veintiún mil", "treinta y un pesos".
const apocope = (w) => (w === 'uno' ? 'un' : w === 'veintiuno' ? 'veintiún' : w)

function below100(n) {
  if (n < 30) return apocope(SMALL[n])
  const t = TENS[Math.floor(n / 10)]
  return n % 10 ? `${t} y ${apocope(SMALL[n % 10])}` : t
}

function below1000(n) {
  if (n === 100) return 'cien'
  const h = Math.floor(n / 100)
  return [HUNDREDS[h], n % 100 ? below100(n % 100) : ''].filter(Boolean).join(' ')
}

/** 20000 → "veinte mil pesos" · 1 → "un peso" · 2000000 → "dos millones de pesos". */
export function amountToSpanish(n) {
  n = Math.floor(n)
  if (!(n > 0) || n > 999_999_999) return `${n} pesos`
  const millions = Math.floor(n / 1_000_000)
  const thousands = Math.floor((n % 1_000_000) / 1000)
  const rest = n % 1000
  const parts = []
  if (millions) parts.push(millions === 1 ? 'un millón' : `${below1000(millions)} millones`)
  if (thousands) parts.push(thousands === 1 ? 'mil' : `${below1000(thousands)} mil`)
  if (rest) parts.push(below1000(rest))
  const words = parts.join(' ')
  if (n === 1) return 'un peso'
  return `${words}${n % 1_000_000 === 0 ? ' de' : ''} pesos`
}

/** "ANA GOMEZ" → "Ana" (o "Ana Gomez"). Solo letras: el texto va a un motor de voz. */
export function niceName(raw, firstOnly) {
  const words = String(raw)
    .replace(/[^\p{L}\s]/gu, ' ')
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1).toLowerCase())
  return (firstOnly ? words.slice(0, 1) : words.slice(0, 3)).join(' ')
}
