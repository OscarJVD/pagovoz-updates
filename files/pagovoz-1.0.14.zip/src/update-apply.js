// Aplica una actualización ya descargada y verificada. Corre AL ARRANCAR, antes de cargar la app:
// así ningún archivo está en uso (en Windows no se pueden reemplazar archivos abiertos).
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

/** Lo único que una actualización puede reemplazar. */
export const REPLACEABLE = ['src', 'public', 'node_modules', 'package.json', 'package-lock.json']
const MAX_ATTEMPTS = 2

const readJson = (file) => {
  try {
    return JSON.parse(readFileSync(file, 'utf8'))
  } catch {
    return null
  }
}
const move = (from, to) => {
  try {
    renameSync(from, to)
  } catch {
    cpSync(from, to, { recursive: true })
    rmSync(from, { recursive: true, force: true })
  }
}

export function paths(dataDir) {
  const dir = join(dataDir, 'update')
  return { dir, stage: join(dir, 'stage'), backup: join(dir, 'backup'), pending: join(dir, 'pending.json'), last: join(dir, 'last.json'), failed: join(dir, 'failed.json') }
}

/** → 'applied' | 'rolledback' | 'retrying' | 'none' */
export function bootUpdate({ root, dataDir, log = console.log }) {
  const P = paths(dataDir)
  const p = readJson(P.pending)
  if (!p) return 'none'

  if (p.state === 'staged') {
    if (!existsSync(P.stage)) {
      rmSync(P.pending, { force: true })
      return 'none'
    }
    rmSync(P.backup, { recursive: true, force: true })
    mkdirSync(P.backup, { recursive: true })
    const applied = []
    for (const name of readdirSync(P.stage)) {
      if (!REPLACEABLE.includes(name)) continue
      if (existsSync(join(root, name))) move(join(root, name), join(P.backup, name))
      move(join(P.stage, name), join(root, name))
      applied.push(name)
    }
    rmSync(P.stage, { recursive: true, force: true })
    writeFileSync(P.pending, JSON.stringify({ ...p, state: 'applied', attempts: 1, applied }))
    log(`Actualización a ${p.version} aplicada (${applied.join(', ')}).`)
    return 'applied'
  }

  if (p.state === 'applied') {
    // La app lo marca "sano" tras 45 s funcionando. Si llegamos aquí otra vez sin eso, se cayó al arrancar.
    if ((p.attempts ?? 0) >= MAX_ATTEMPTS) {
      for (const name of p.applied ?? []) {
        if (!existsSync(join(P.backup, name))) continue
        rmSync(join(root, name), { recursive: true, force: true })
        move(join(P.backup, name), join(root, name))
      }
      const failed = readJson(P.failed) ?? []
      writeFileSync(P.failed, JSON.stringify([...new Set([...failed, p.version])]))
      writeFileSync(P.last, JSON.stringify({ rolledBack: p.version, from: p.from, at: Date.now() }))
      rmSync(P.pending, { force: true })
      log(`La versión ${p.version} no arrancó bien: se volvió a ${p.from}.`)
      return 'rolledback'
    }
    writeFileSync(P.pending, JSON.stringify({ ...p, attempts: (p.attempts ?? 0) + 1 }))
    return 'retrying'
  }
  return 'none'
}
