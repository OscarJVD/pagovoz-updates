// Lee los avisos de Nequi de dinero recibido y verifica que sean auténticos.
// El HTML de Nequi llega a veces con las celdas pegadas ("Estado:AprobadaFecha:…"):
// cada etiqueta conocida se pasa a su propia línea antes de leer.
const LABELS = /(Monto|Estado|Fecha|Hora|Pagador|Banco|Referencia|N[uú]mero de transacci[oó]n|M[eé]todo de pago|Comisi[oó]n|Valor)\s*:/gi
const field = (t, name) => new RegExp(`^${name}:\\s*(.+?)\\s*$`, 'im').exec(t)?.[1] ?? ''

export const toAmount = (raw) => {
  const n = Number(String(raw).replace(/,\d{1,2}$/, '').replace(/[.,\s]/g, ''))
  return Number.isInteger(n) && n > 0 ? n : 0
}

// Cuenta personal: "Recibiste 19.000 de LUISA TORRES el 18 de noviembre de 2026 a las 3:56 p.m, desde el banco…"
const RECEIVED_RE = /\bRecibiste\s+\$?\s*(\d[\d.,]*)\s+de\s+(.+?)(?=\s+el\s+\d|\s*,?\s+desde\b|\s*[.,](?:\s|$)|$)/i

/**
 * Devuelve { amount, payer, approved, kind } o null si el texto no es un aviso de dinero recibido.
 *  - method: cómo llegó el dinero → qr | llave | nequi ('' si el aviso no lo dice).
 *  - kind "venta":    Nequi Negocios ("Detalle de tu venta por Bre-B"); solo vale con Estado: Aprobada.
 *  - kind "recibido": cuenta personal ("¡Recibiste plata por Bre-B!"); el correo ya es el comprobante.
 */
export function parsePayment(text, subject = '') {
  const t = String(text).replace(/\r/g, '').replace(/[ \t\u00a0]+/g, ' ')
  if (/venta/i.test(`${subject} ${t}`)) {
    const rows = t.replace(LABELS, '\n$1:')
    const amount = toAmount(/^\$?\s*([\d.,]+)/.exec(field(rows, 'Monto').replace(/^\$\s*/, ''))?.[1] ?? /venta exitosa por\s*\$\s*([\d.,]+)/i.exec(t)?.[1] ?? '')
    if (!amount) return null
    const how = field(rows, 'M[eé]todo de pago')
    const method = /\bqr\b/i.test(how) ? 'qr' : /llave/i.test(how) ? 'llave' : ''
    return { amount, payer: field(rows, 'Pagador'), approved: /^aprobad[ao]\b/i.test(field(rows, 'Estado')), kind: 'venta', method }
  }
  const r = RECEIVED_RE.exec(t.replace(/\s+/g, ' '))
  const amount = toAmount(r?.[1] ?? '')
  return amount ? { amount, payer: r[2].trim(), approved: true, kind: 'recibido', method: 'llave' } : null
}

export const domainOf = (address) => String(address).split('@').pop().trim().toLowerCase()
export const inDomains = (domain, allowed) => allowed.some((d) => domain === d || domain.endsWith(`.${d}`))

/** Primer Authentication-Results del mensaje: el que añadió tu servidor de correo al recibirlo. */
export function authResultsOf(source) {
  const raw = Buffer.from(source).toString('latin1')
  const end = raw.search(/\r?\n\r?\n/)
  const headers = end > 0 ? raw.slice(0, end) : raw
  const m = /^Authentication-Results:([^\r\n]*(?:\r?\n[ \t][^\r\n]*)*)/im.exec(headers)
  return m ? m[1].replace(/\r?\n[ \t]+/g, ' ').trim() : ''
}

export function verifySender(from, authResults, allowed, requireDkim) {
  const domain = domainOf(from)
  if (!inDomains(domain, allowed)) return { ok: false, why: `remitente ${domain || '?'} no permitido` }
  if (!requireDkim) return { ok: true, why: 'remitente permitido (DKIM no exigido)' }
  const dkim = [...authResults.matchAll(/dkim=pass[^;]*?header\.(?:i=@?|d=)([a-z0-9.-]+)/gi)].map((m) => m[1].toLowerCase())
  return dkim.some((d) => inDomains(d, allowed))
    ? { ok: true, why: 'DKIM verificado' }
    : { ok: false, why: 'DKIM no verificado: posible correo falso' }
}
