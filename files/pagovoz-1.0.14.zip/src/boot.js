// Punto de entrada: aplica una actualización pendiente (o la deshace si falló) y luego arranca la app.
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { bootUpdate } from './update-apply.js'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
try {
  bootUpdate({ root, dataDir: process.env.PAGOVOZ_DATA || join(process.cwd(), 'data') })
} catch (e) {
  console.error('actualización:', e.message)
}
await import('./server.js')
