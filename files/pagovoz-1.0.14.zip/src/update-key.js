// Llave PÚBLICA con la que se verifican las actualizaciones. La privada vive solo en el Mac del autor y en los secretos de GitHub Actions.
export const UPDATE_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA8yP2b8KHZfI3MFRLgxZx+CCDRIf/c4c5uu9jOt5rwSc=
-----END PUBLIC KEY-----`
