import { ImapFlow } from 'imapflow'

import { domainOf, inDomains } from './parse.js'
import { getBox, getConfig, setBox } from './store.js'

const POLL_MS = 30_000

const REASONS = {
  ECONNREFUSED: 'el servidor rechazó la conexión (revisa servidor y puerto)',
  ENOTFOUND: 'no se encontró el servidor (revisa el nombre y el internet)',
  ETIMEDOUT: 'se agotó el tiempo (revisa el internet)',
  ECONNRESET: 'se cortó la conexión',
}
/** Mensaje entendible para un error de conexión IMAP. */
export const explain = (e) =>
  e.authenticationFailed ? 'el correo o la contraseña de aplicación fueron rechazados' : e.responseText || REASONS[e.code] || e.message || e.code || 'no se pudo conectar'

const newClient = (m) =>
  new ImapFlow({ host: m.host, port: m.port, secure: m.port === 993, auth: { user: m.user, pass: m.pass }, logger: false })

/** Un correo: escucha el buzón con IMAP IDLE (push) y revisa cada 30 s por si Gmail pierde un aviso. */
function createAccountWatcher(id, onMail) {
  let client
  let stopped = true
  let retry = 0
  let timers = []
  let syncing = false
  let again = false
  let origin = 'push'
  let pending = 'push'
  let status = { state: 'stopped' }
  const account = () => getConfig().mails.find((a) => a.id === id)

  const clear = () => {
    timers.forEach((t) => (clearTimeout(t), clearInterval(t)))
    timers = []
  }

  async function syncOnce() {
    const { lastUid } = getBox(id)
    const found = []
    for await (const m of client.fetch(`${lastUid + 1}:*`, { uid: true, envelope: true }, { uid: true })) {
      if (m.uid > lastUid) found.push(m)
    }
    for (const m of found.sort((a, b) => a.uid - b.uid)) {
      const from = m.envelope?.from?.[0]?.address ?? ''
      if (inDomains(domainOf(from), getConfig().senders)) {
        const full = await client.fetchOne(m.uid, { source: true }, { uid: true })
        await onMail(full.source, account(), origin)
      }
      setBox(id, { lastUid: m.uid })
    }
    status = { ...status, lastCheck: Date.now() }
  }

  /** origin: push (Gmail avisó por IDLE) · respaldo (revisión periódica) · conexion (al conectar: avisos que llegaron mientras estaba apagado). */
  async function sync(why = 'push') {
    if (syncing) {
      again = true
      if (why === 'push') pending = 'push' // lo que llegue mientras tanto vino por IDLE
      return
    }
    syncing = true
    pending = why
    try {
      do {
        again = false
        origin = pending
        pending = 'respaldo'
        await syncOnce()
      } while (again)
    } catch (e) {
      console.error(`correo ${id}:`, e.message)
    } finally {
      syncing = false
    }
  }

  function reconnect(authFailed) {
    if (stopped) return
    const delay = authFailed ? 120_000 : Math.min(5000 * 2 ** retry++, 120_000)
    timers.push(setTimeout(run, delay))
  }

  async function run() {
    clear()
    const m = account()
    if (!m?.enabled || !m.user || !m.pass) return void (status = { state: 'unconfigured' })
    status = { state: 'connecting' }
    const c = (client = newClient(m))
    c.on('error', (e) => (status = { state: 'error', error: explain(e) }))
    c.on('close', () => {
      if (client === c && !stopped) {
        if (status.state === 'connected') status = { state: 'connecting' }
        reconnect(false)
      }
    })
    c.on('exists', () => sync('push'))
    try {
      await c.connect()
      await c.mailboxOpen(m.mailbox)
      const box = getBox(id)
      // Primera vez (o buzón nuevo): solo cuentan los correos que lleguen desde ahora.
      if (!box.lastUid || box.uidValidity !== Number(c.mailbox.uidValidity)) {
        setBox(id, { lastUid: c.mailbox.uidNext - 1, uidValidity: Number(c.mailbox.uidValidity) })
      }
      retry = 0
      status = { state: 'connected', since: Date.now() }
      await sync('conexion')
      timers.push(setInterval(() => sync('respaldo'), POLL_MS))
    } catch (e) {
      status = { state: 'error', error: explain(e) }
      c.removeAllListeners('close')
      reconnect(e.authenticationFailed)
    }
  }

  return {
    status: () => status,
    start() {
      stopped = false
      return run()
    },
    async stop() {
      stopped = true
      clear()
      const c = client
      client = undefined
      status = { state: 'stopped' }
      await c?.logout().catch(() => {})
    },
  }
}

const keyOf = (a) => JSON.stringify([a.host, a.port, a.user, a.pass, a.mailbox, a.enabled])

/** Mantiene una conexión por cada correo configurado. `sync()` altas, cambios y bajas sin tocar las demás. */
export function createWatcher(onMail) {
  const running = new Map()
  return {
    status: () => Object.fromEntries([...running].map(([id, r]) => [id, r.w.status()])),
    async sync() {
      const mails = getConfig().mails
      for (const [id, r] of running) {
        const a = mails.find((x) => x.id === id)
        if (!a || keyOf(a) !== r.key) {
          await r.w.stop()
          running.delete(id)
        }
      }
      for (const a of mails) {
        if (running.has(a.id)) continue
        const w = createAccountWatcher(a.id, onMail)
        running.set(a.id, { key: keyOf(a), w })
        w.start()
      }
    },
    async stop() {
      await Promise.all([...running.values()].map((r) => r.w.stop()))
      running.clear()
    },
  }
}

/** Conecta con los datos dados y cuenta cuántos correos de Nequi hay. Devuelve también los `lastN` más recientes. */
export async function testMail(m, senders, { lastN = 0 } = {}) {
  const c = newClient(m)
  await c.connect()
  try {
    await c.mailboxOpen(m.mailbox)
    const uids = (await c.search({ from: senders[0] ?? 'nequi.com.co' }, { uid: true })) || []
    const last = []
    for (const uid of uids.sort((a, b) => b - a).slice(0, lastN)) {
      last.push((await c.fetchOne(uid, { source: true }, { uid: true })).source)
    }
    return { total: c.mailbox.exists, fromSender: uids.length, last }
  } finally {
    await c.logout().catch(() => {})
  }
}
