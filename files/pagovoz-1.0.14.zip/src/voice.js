import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, mkdtempSync, readdirSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { MsEdgeTTS, OUTPUT_FORMAT } from 'msedge-tts'

import { DATA_DIR } from './store.js'

const CACHE = join(DATA_DIR, 'cache')
const run = (cmd, args, env = {}) =>
  new Promise((resolve, reject) =>
    execFile(cmd, args, { timeout: 30_000, windowsHide: true, env: { ...process.env, ...env } }, (e) => (e ? reject(e) : resolve())),
  )

const WIN_PLAY = `Add-Type -AssemblyName presentationCore
$p = New-Object System.Windows.Media.MediaPlayer
$p.Open([uri]$env:PV_FILE); $p.Volume = [double]$env:PV_VOL
for ($i = 0; $i -lt 100 -and -not $p.NaturalDuration.HasTimeSpan; $i++) { Start-Sleep -Milliseconds 50 }
$ms = if ($p.NaturalDuration.HasTimeSpan) { [int]$p.NaturalDuration.TimeSpan.TotalMilliseconds } else { 3000 }
$p.Play(); Start-Sleep -Milliseconds ($ms + 300)`

const WIN_SAY = `Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
try { $s.SelectVoiceByHints('NotSet', 'NotSet', 0, [Globalization.CultureInfo]'es-MX') } catch {}
if ($env:PV_VOICE) { try { $s.SelectVoice($env:PV_VOICE) } catch {} }
$s.Volume = [int]$env:PV_VOL
$s.Speak($env:PV_TEXT)`

export function playFile(file, volume = 100) {
  const v = Math.max(0, Math.min(100, volume)) / 100
  if (process.platform === 'darwin') return run('afplay', ['-v', String(v), file])
  if (process.platform === 'win32') {
    return run('powershell', ['-NoProfile', '-NonInteractive', '-Command', WIN_PLAY], { PV_FILE: file, PV_VOL: String(v) })
  }
  return run('ffplay', ['-nodisp', '-autoexit', '-loglevel', 'quiet', '-volume', String(v * 100), file])
}

/** Voz instalada en el sistema: sin internet, calidad básica. Es el respaldo de la neuronal. */
function systemSpeak(text, v) {
  if (process.platform === 'darwin') return run('say', ['-v', v.systemVoice || 'Paulina', text])
  if (process.platform === 'win32') {
    return run('powershell', ['-NoProfile', '-NonInteractive', '-Command', WIN_SAY], {
      PV_TEXT: text,
      PV_VOICE: v.systemVoice,
      PV_VOL: String(v.volume),
    })
  }
  return run('espeak', ['-v', 'es', text])
}

const esc = (s) => s.replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' })[c])

/** Voz neuronal de Microsoft Edge. Cada frase se guarda en disco: la segunda vez suena al instante y sin internet. */
async function edgeFile(text, voice) {
  const file = join(CACHE, `${createHash('sha1').update(`${voice}|${text}`).digest('hex').slice(0, 24)}.mp3`)
  if (existsSync(file)) return file
  const tmp = mkdtempSync(join(tmpdir(), 'pagovoz-'))
  const tts = new MsEdgeTTS({ connectionTimeoutMs: 8000, synthesisTimeoutMs: 15_000 })
  try {
    await tts.setMetadata(voice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3)
    const { audioFilePath } = await tts.toFile(tmp, esc(text))
    renameSync(audioFilePath, file)
    return file
  } finally {
    tts.close()
    rmSync(tmp, { recursive: true, force: true })
  }
}

function chimeFile() {
  const file = join(DATA_DIR, 'chime.wav')
  if (existsSync(file)) return file
  const sr = 22_050
  const samples = []
  for (const [hz, secs] of [[880, 0.12], [1318, 0.22]]) {
    const n = Math.floor(sr * secs)
    for (let i = 0; i < n; i++) {
      const env = Math.min(1, i / 200) * Math.min(1, (n - i) / (sr * 0.08))
      samples.push(Math.round(Math.sin((2 * Math.PI * hz * i) / sr) * 0.35 * 32767 * env))
    }
  }
  const buf = Buffer.alloc(44 + samples.length * 2)
  buf.write('RIFF', 0)
  buf.writeUInt32LE(36 + samples.length * 2, 4)
  buf.write('WAVEfmt ', 8)
  buf.writeUInt32LE(16, 16)
  buf.writeUInt16LE(1, 20)
  buf.writeUInt16LE(1, 22)
  buf.writeUInt32LE(sr, 24)
  buf.writeUInt32LE(sr * 2, 28)
  buf.writeUInt16LE(2, 32)
  buf.writeUInt16LE(16, 34)
  buf.write('data', 36)
  buf.writeUInt32LE(samples.length * 2, 40)
  samples.forEach((s, i) => buf.writeInt16LE(s, 44 + i * 2))
  writeFileSync(file, buf)
  return file
}

export async function speak(v, text) {
  // La síntesis empieza ya, mientras suena el "ding".
  const pending = v.engine === 'edge' ? edgeFile(text, v.voice).catch((e) => (console.error('voz neuronal falló, uso la del sistema:', e.message), null)) : null
  if (v.chime) await playFile(chimeFile(), v.volume).catch(() => {})
  const file = await pending
  if (file) return playFile(file, v.volume)
  return systemSpeak(text, v)
}

let chain = Promise.resolve()
let queued = 0
let lastSpoken = 0
/** Una voz a la vez: dos pagos seguidos no se pisan. */
export const enqueue = (fn) => {
  queued++
  return (chain = chain
    .then(fn)
    .catch((e) => console.error('voz:', e.message))
    .finally(() => {
      queued--
      lastSpoken = Date.now()
    }))
}
/** Hay una voz en cola o sonó hace menos de 30 s: mal momento para reiniciar la app. */
export const isBusy = () => queued > 0 || Date.now() - lastSpoken < 30_000

export function pruneCache(days = 30) {
  const limit = Date.now() - days * 86_400_000
  for (const f of readdirSync(CACHE)) {
    const p = join(CACHE, f)
    if (statSync(p).mtimeMs < limit) rmSync(p, { force: true })
  }
}

let voices
export async function listVoices() {
  if (voices) return voices
  const tts = new MsEdgeTTS({ connectionTimeoutMs: 6000 })
  try {
    voices = (await tts.getVoices()).filter((x) => x.Locale.startsWith('es-')).map((x) => ({ id: x.ShortName, label: `${x.ShortName.replace('Neural', '')} (${x.Gender === 'Female' ? 'mujer' : 'hombre'})` }))
  } catch {
    voices = ['es-CO-SalomeNeural', 'es-CO-GonzaloNeural', 'es-MX-DaliaNeural', 'es-MX-JorgeNeural', 'es-ES-ElviraNeural', 'es-ES-AlvaroNeural'].map((id) => ({ id, label: id.replace('Neural', '') }))
  } finally {
    tts.close()
  }
  return voices
}
