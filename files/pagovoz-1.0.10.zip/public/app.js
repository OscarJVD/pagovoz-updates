// Panel de control. Textos de ayuda: help.js. Estilos: app.css.
const H = window.PV_HELP
const $ = (s, r = document) => r.querySelector(s)
const $$ = (s, r = document) => [...r.querySelectorAll(s)]
let cfg, polling, formDirty = false, lastStatus = null, lastPhone = null, lastUpdate = null, lastHistory = []

// ── Utilidades ──────────────────────────────────────────────────────────
const api = async (method, path, body) => {
  const r = await fetch(path, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })
  const data = await r.json().catch(() => ({}))
  if (r.status === 401 && path !== '/api/login') { showLogin(); throw new Error('Inicia sesión') }
  if (!r.ok) throw new Error(data.error || 'Error')
  return data
}
const get = (o, p) => p.split('.').reduce((a, k) => a?.[k], o)
const set = (o, p, v) => { const ks = p.split('.'); ks.slice(0, -1).reduce((a, k) => (a[k] ??= {}), o)[ks.at(-1)] = v }
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c])
const money = (n) => '$' + Number(n).toLocaleString('es-CO')
const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']
/** «2 nov 2026 10:40pm» */
const fmtDate = (t) => {
  const d = new Date(t), h = d.getHours() % 12 || 12
  return `${d.getDate()} ${MESES[d.getMonth()]} ${d.getFullYear()} ${h}:${String(d.getMinutes()).padStart(2, '0')}${d.getHours() >= 12 ? 'pm' : 'am'}`
}
const pn = () => cfg?.ui?.productName || 'PagoVoz'
const fmt = (s) => String(s).replaceAll('{producto}', pn())
const flags = { read: () => { try { return JSON.parse(localStorage.getItem('pv.flags') || '{}') } catch { return {} } }, get(k) { return !!this.read()[k] }, set(k, v = true) { try { localStorage.setItem('pv.flags', JSON.stringify({ ...this.read(), [k]: v })) } catch {} } }
const toast = (m) => { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('on'), 2600) }
const busy = async (btn, fn) => { btn.disabled = true; try { await fn() } catch (e) { toast(e.message) } finally { btn.disabled = false } }
const out = (sel, text, ok = true) => { const p = $(sel); p.textContent = text; p.className = 'out show'; p.style.color = ok ? '' : 'var(--bad)' }
const initials = (name) => (name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map((w) => Array.from(w)[0]).join('') || 'P').toUpperCase()
const readableOn = (hex) => {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4))
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.18 ? '#111827' : '#ffffff'
}

// ── Marca y tema ────────────────────────────────────────────────────────
function applyUi(ui) {
  const r = document.documentElement
  const dark = ui.theme === 'auto' ? matchMedia('(prefers-color-scheme: dark)').matches : ui.theme === 'dark'
  r.dataset.theme = dark ? 'dark' : 'light'
  r.dataset.scale = ui.fontScale
  r.dataset.radius = ui.radius
  r.dataset.density = ui.density
  r.dataset.font = ui.customFont ? 'custom' : ui.font
  r.style.setProperty('--primary', ui.primary)
  r.style.setProperty('--on-primary', readableOn(ui.primary))
  r.style.setProperty('--accent', ui.accent)
  if (ui.customFont) {
    r.style.setProperty('--font-custom', `'${ui.customFont}'`)
    let l = $('#customFontLink')
    if (!l) { l = document.createElement('link'); l.id = 'customFontLink'; l.rel = 'stylesheet'; document.head.append(l) }
    const href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(ui.customFont).replace(/%20/g, '+')}:wght@400;600;700&display=swap`
    if (l.href !== href) l.href = href
  } else $('#customFontLink')?.remove()
  document.title = `${ui.businessName} · ${ui.productName}`
  $('#themeColor').content = ui.primary
  $('#brandName').textContent = ui.businessName
  $('#brandProduct').textContent = ui.productName
  $('#loginName').textContent = ui.businessName
  $('#mark').textContent = $('#loginMark').textContent = initials(ui.businessName)
  const src = ui.hasLogo ? `/brand/logo?v=${ui.brandV}` : ui.logoUrl
  const logo = $('#logo'); logo.hidden = !src; if (src && logo.getAttribute('src') !== src) logo.src = src
  $('#mark').hidden = !!src
  const fav = `/brand/favicon?v=${ui.brandV}&c=${encodeURIComponent(ui.primary + ui.faviconText + ui.businessName)}`
  if ($('#favicon').getAttribute('href') !== fav) { $('#favicon').href = fav; $('#favPrev').src = fav }
  $$('.pn').forEach((e) => (e.textContent = ui.productName))
  $('#logoPrev').hidden = !(ui.hasLogo || ui.logoUrl)
  if (ui.hasLogo || ui.logoUrl) $('#logoPrev').src = src
  $('#logoNone').hidden = !!(ui.hasLogo || ui.logoUrl)
  $('#logoDel').hidden = !ui.hasLogo
  $('#favDel').hidden = !ui.hasFavicon
  $$('[data-video]').forEach((b) => { if (b.dataset.vlabel !== undefined || b.matches('.btn')) b.hidden = !ui.tutorials })
  $('#vidCard').hidden = !ui.tutorials
  $$('.swatch').forEach((s) => s.setAttribute('aria-pressed', String(s.dataset.p === ui.primary && s.dataset.a === ui.accent)))
}

const PRESETS = [['Violeta', '#7c3aed', '#06b6d4'], ['Azul', '#2563eb', '#f59e0b'], ['Verde', '#059669', '#f97316'], ['Naranja', '#ea580c', '#0ea5e9'], ['Rojo', '#dc2626', '#14b8a6'], ['Rosa', '#db2777', '#8b5cf6'], ['Grafito', '#374151', '#22c55e']]
$('#swatches').innerHTML = PRESETS.map(([n, p, a]) => `<button type="button" class="swatch" style="--a:${p};--b:${a}" data-p="${p}" data-a="${a}" aria-label="Combinación ${n}" title="${n}"></button>`).join('')
$('#swatches').addEventListener('click', (e) => {
  const s = e.target.closest('.swatch'); if (!s) return
  $('[data-k="ui.primary"]').value = s.dataset.p; $('[data-k="ui.accent"]').value = s.dataset.a
  formDirty = true; previewUi()
})
const previewUi = () => applyUi({ ...cfg.ui, ...collect($('#diseno')).ui })

// ── Ayuda contextual (globitos ?) ───────────────────────────────────────
function renderTips(root = document) {
  $$('span[data-tip]', root).forEach((el) => {
    const k = el.dataset.tip
    if (!H.tips[k]) return el.remove()
    const b = document.createElement('button')
    b.type = 'button'; b.className = 'tip'; b.textContent = '?'; b.dataset.tipKey = k
    b.setAttribute('aria-label', 'Ayuda sobre este campo'); b.setAttribute('aria-expanded', 'false')
    el.replaceWith(b)
  })
}
const tipbox = $('#tipbox')
let tipBtn = null
function showTip(b, pinned) {
  const t = H.tips[b.dataset.tipKey]; if (!t) return
  tipBtn?.setAttribute('aria-expanded', 'false')
  tipBtn = b; b.setAttribute('aria-expanded', 'true'); b.dataset.pinned = pinned ? '1' : ''
  tipbox.innerHTML = esc(fmt(t.t)) + (t.v && cfg?.ui.tutorials ? `<br><a href="#" data-video="${t.v}">▶ Ver el video</a>` : '')
  tipbox.hidden = false
  const r = b.getBoundingClientRect(), w = tipbox.offsetWidth, h = tipbox.offsetHeight
  const left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), innerWidth - w - 8)
  const top = r.bottom + h + 14 > innerHeight ? Math.max(8, r.top - h - 10) : r.bottom + 10
  Object.assign(tipbox.style, { left: left + 'px', top: top + 'px' })
  b.setAttribute('aria-describedby', 'tipbox')
}
function hideTip() { tipbox.hidden = true; tipBtn?.setAttribute('aria-expanded', 'false'); tipBtn?.removeAttribute('aria-describedby'); tipBtn = null }
document.addEventListener('mouseover', (e) => { const b = e.target.closest?.('.tip'); if (b && b !== tipBtn) showTip(b, false) })
document.addEventListener('mouseout', (e) => { const b = e.target.closest?.('.tip'); if (b && b === tipBtn && !b.dataset.pinned && !tipbox.contains(e.relatedTarget)) hideTip() })
document.addEventListener('focusin', (e) => { const b = e.target.closest?.('.tip'); if (b) showTip(b, false) })
document.addEventListener('focusout', (e) => { if (e.target.closest?.('.tip') && !tipbox.contains(e.relatedTarget)) hideTip() })
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hideTip() })
document.addEventListener('click', (e) => {
  const b = e.target.closest('.tip')
  if (b) { b === tipBtn && b.dataset.pinned ? hideTip() : showTip(b, true); return }
  const v = e.target.closest('[data-video]')
  if (v) { e.preventDefault(); hideTip(); openVideo(v.dataset.video); return }
  if (!e.target.closest('#tipbox')) hideTip()
})

// ── Videos tutoriales ───────────────────────────────────────────────────
const tut = (id) => H.tutorials.find((t) => t.id === id)
$$('[data-video]').forEach((b) => { const t = tut(b.dataset.video); if (t) b.textContent = `▶ Ver video (${t.secs} s)` })
const videoUrl = (id, ext) => `${cfg.ui.videoBase}/${id}.${ext}`
function renderVideoGrid() {
  $('#vGrid').innerHTML = H.tutorials.map((t) => `<button class="vcard" data-video="${t.id}"><div class="thumb" style="background-image:url('${esc(videoUrl(t.id, 'jpg'))}')"><span class="play" aria-hidden="true">▶</span></div><div class="meta"><b>${esc(fmt(t.title))}</b><span>${t.secs} segundos</span></div></button>`).join('')
}
const dlg = $('#video')
let vGoTab = null
function openVideo(id) {
  const t = tut(id); if (!t) return
  $('#vTitle').textContent = fmt(t.title)
  $('#vSteps').innerHTML = t.steps.map((s) => `<li>${esc(fmt(s))}</li>`).join('')
  vGoTab = t.tab
  $('#vGo').hidden = !t.tab
  const v = $('#vPlayer'), fail = $('#vFail')
  fail.hidden = true; v.hidden = !cfg.ui.tutorials
  if (cfg.ui.tutorials) {
    v.poster = videoUrl(id, 'jpg'); v.src = videoUrl(id, 'mp4')
    v.onerror = () => { fail.hidden = false; v.hidden = true }
  } else { v.hidden = true }
  dlg.showModal()
}
$('#vClose').addEventListener('click', () => dlg.close())
dlg.addEventListener('close', () => { const v = $('#vPlayer'); v.pause(); v.removeAttribute('src'); v.load() })
dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close() })
$('#vGo').addEventListener('click', () => { dlg.close(); go(vGoTab) })

// ── Navegación ──────────────────────────────────────────────────────────
function go(tab) {
  if (!$('#' + tab)?.classList.contains('page')) return
  $$('#tabs button').forEach((b) => (b.dataset.t === tab ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current')))
  $$('section.page').forEach((s) => s.classList.toggle('on', s.id === tab))
  history.replaceState(null, '', '#' + tab)
  scrollTo({ top: 0 })
  $('#main').focus({ preventScroll: true })
  if (tab === 'celular') loadPhone().catch(() => {})
  if (tab === 'actualizar') loadUpdate().catch(() => {})
}
$('#tabs').addEventListener('click', (e) => { const b = e.target.closest('button[data-t]'); if (b) go(b.dataset.t) })
addEventListener('hashchange', () => go(location.hash.slice(1)))

// ── Formularios ─────────────────────────────────────────────────────────
function fill(c) {
  $$('[data-k]').forEach((el) => {
    let v = get(c, el.dataset.k)
    if (el.dataset.k === 'monitor.token') { el.placeholder = c.monitor.hasToken ? '•••• guardado (vacío = conservarlo)' : 'Lo entrega quien instala'; el.value = ''; return }
    if (el.dataset.k === 'phone.relay.token') { el.placeholder = c.phone.relay.hasToken ? '•••• guardado (vacío = conservarlo)' : 'No hace falta en ntfy.sh'; el.value = ''; return }
    if (Array.isArray(v)) v = v.join(', ')
    if (el.type === 'checkbox') el.checked = !!v; else el.value = v ?? ''
  })
  renderAccounts(c.mails)
  $('#volN').textContent = c.voice.volume
  $('#paused').checked = c.paused
  $('#pinHint').textContent = c.hasPin ? 'El panel pide PIN al entrar. Déjalo vacío para quitarlo.' : 'Sin PIN: cualquiera que abra este panel en el equipo puede cambiar la configuración.'
}
function collect(root) {
  const patch = {}
  $$('[data-k]', root).forEach((el) => {
    const v = el.type === 'checkbox' ? el.checked : el.type === 'number' || el.type === 'range' ? Number(el.value) : el.value
    set(patch, el.dataset.k, v)
  })
  return patch
}
async function save(patch, msg = 'Guardado ✓') {
  const r = await api('PUT', '/api/config', patch)
  cfg = r.config; formDirty = false; fill(cfg); applyUi(cfg.ui); renderOnboarding(); toast(msg)
}
document.addEventListener('input', (e) => {
  if (e.target.closest?.('#accounts')) formDirty = true
  if (e.target.dataset?.k) {
    formDirty = true
    if (e.target.dataset.k.startsWith('ui.')) previewUi()
    if (e.target.id === 'vol') $('#volN').textContent = e.target.value
  }
})
$$('[data-act=save]').forEach((b) => b.addEventListener('click', () => busy(b, () => save(collect(b.closest('section'))))))
$$('[data-ins]').forEach((c) => c.addEventListener('click', () => { const i = $('#tpl'); i.value = (i.value + ' ' + c.dataset.ins).trim(); formDirty = true }))
$('#paused').addEventListener('change', async (e) => { await api('POST', '/api/pause', { paused: e.target.checked }); load() })

// ── Correos ─────────────────────────────────────────────────────────────
const STATES = { connected: ['Escuchando correo', 'var(--ok)'], connecting: ['Conectando…', 'var(--warn)'], error: ['Error de correo', 'var(--bad)'], unconfigured: ['Falta configurar el correo', 'var(--warn)'], stopped: ['Detenido', 'var(--muted)'] }
const lab = (m) => m.label || m.user || 'Correo nuevo'
let acctSig = ''
function renderAccounts(mails) {
  const sig = JSON.stringify(mails.map(({ pass, ...rest }) => rest))
  if (sig === acctSig) return
  acctSig = sig
  $('#accounts').innerHTML = ''
  mails.forEach(addAccount)
  $('#acctEmpty').hidden = mails.length > 0
}
function addAccount(m = { id: '', label: '', user: '', host: 'imap.gmail.com', port: 993, mailbox: 'INBOX', enabled: true, hasPass: false }) {
  const d = document.createElement('div')
  d.className = 'acct'; d.dataset.id = m.id; d.dataset.mailbox = m.mailbox
  d.innerHTML = `<div class="acct-h"><span class="dot"></span><b></b><span class="st"></span>
    <label class="switch"><input type="checkbox" data-f="enabled"><span class="txt"><b>Activo</b></span></label><button class="btn secondary sm" data-rm type="button">Quitar</button></div>
    <div class="fields">
      <div class="field"><label>Nombre (opcional)</label><input type="text" data-f="label" placeholder="Tienda, Personal…" maxlength="40"></div>
      <div class="field"><label>Correo</label><input type="text" data-f="user" placeholder="negocio@gmail.com" autocomplete="off" inputmode="email"></div>
      <div class="field"><label>Contraseña de aplicación <span data-tip="appPassword"></span></label><input type="password" data-f="pass" autocomplete="new-password"></div>
      <div class="field"><label>Servidor IMAP <span data-tip="imap"></span></label><input type="text" data-f="host"></div>
      <div class="field"><label>Puerto</label><input type="number" data-f="port"></div>
    </div>
    <div class="actions"><button class="btn secondary sm" data-test type="button">Probar conexión</button></div><pre class="out"></pre>`
  const f = (k) => d.querySelector(`[data-f=${k}]`)
  d.querySelector('b').textContent = lab(m)
  f('enabled').checked = m.enabled; f('label').value = m.label; f('user').value = m.user; f('host').value = m.host; f('port').value = m.port
  f('pass').placeholder = m.hasPass ? '•••• guardada (vacía = conservarla)' : '16 letras de Google'
  $('#accounts').append(d)
  renderTips(d)
  $('#acctEmpty').hidden = true
}
const collectAccounts = () => $$('.acct').map((d) => {
  const f = (k) => d.querySelector(`[data-f=${k}]`)
  return { id: d.dataset.id, label: f('label').value, user: f('user').value, pass: f('pass').value, host: f('host').value, port: Number(f('port').value), mailbox: d.dataset.mailbox, enabled: f('enabled').checked }
})
$('#addMail').addEventListener('click', () => { addAccount(); formDirty = true; $$('.acct').at(-1).querySelector('[data-f=user]').focus() })
$('#saveMails').addEventListener('click', (e) => busy(e.target, async () => { acctSig = ''; await save({ mails: collectAccounts() }, 'Correos guardados ✓') }))
$('#accounts').addEventListener('click', (e) => {
  const d = e.target.closest('.acct'); if (!d) return
  if (e.target.matches('[data-rm]') && confirm('¿Quitar este correo? Dejará de escucharse.')) { d.remove(); formDirty = true; $('#acctEmpty').hidden = $$('.acct').length > 0 }
  if (e.target.matches('[data-test]')) busy(e.target, async () => {
    const pre = d.querySelector('pre'), i = $$('.acct').indexOf(d)
    try { const r = await api('POST', '/api/mail/test', { account: collectAccounts()[i] }); pre.textContent = '✔ ' + r.message; pre.style.color = '' } catch (err) { pre.textContent = '✘ ' + err.message; pre.style.color = 'var(--bad)' }
    pre.className = 'out show'
  })
})

// ── Estado, historial, pruebas ──────────────────────────────────────────
function renderStatus(st) {
  lastStatus = st
  $$('.acct').forEach((d) => {
    const s = st.accounts?.[d.dataset.id]
    const [t, col] = !d.dataset.id ? ['Sin guardar', 'var(--warn)'] : s ? (STATES[s.state] ?? STATES.stopped) : ['', 'var(--muted)']
    d.querySelector('.dot').style.setProperty('--c', col); d.querySelector('.st').style.setProperty('--c', col)
    d.querySelector('.st').textContent = s?.state === 'error' ? 'Error: ' + s.error : t
  })
  const [label, c] = cfg.paused ? ['En pausa', 'var(--warn)'] : STATES[st.state] ?? STATES.stopped
  const p = $('#pill'); p.textContent = label; p.style.setProperty('--c', c); p.title = st.error ?? ''
  $('#pauseHint').textContent = cfg.paused ? 'No suena nada' : st.error ? st.error : 'Suena cada pago confirmado'
}
const METHOD = { llave: 'Llave', qr: 'QR', nequi: 'Nequi' }
const ROUTES = { 'correo:push': 'Correo · aviso inmediato', 'correo:respaldo': 'Correo · respaldo (30 s)', 'correo:conexion': 'Correo · al reconectar', 'celular:nube': 'Celular · Internet', 'celular:wifi': 'Celular · WiFi', prueba: 'Prueba' }
const routeLabel = (x) => ROUTES[x.route] || (x.source === 'correo' ? 'Correo' : x.source === 'celular' ? 'Celular' : x.source || '—') + (x.account && cfg.mails.length > 1 && String(x.route || '').startsWith('correo') ? ` · ${x.account}` : '')
function matchFilters(x) {
  const q = $('#hfQ').value.trim().toLowerCase(), digits = q.replace(/\D/g, '')
  if (q && !(String(x.payer ?? '').toLowerCase().includes(q) || (digits && String(x.amount).includes(digits)))) return false
  const p = $('#hfP').value
  if (p === 'today' && new Date(x.ts).toDateString() !== new Date().toDateString()) return false
  if (p === '7' && Date.now() - x.ts > 7 * 86_400_000) return false
  if ($('#hfS').value !== 'all' && x.status !== $('#hfS').value) return false
  if ($('#hfM').value !== 'all' && x.method !== $('#hfM').value) return false
  const r = $('#hfR').value, route = x.route || x.source || ''
  return r === 'all' || route === r || route.startsWith(r + ':')
}
$('#histFilters').addEventListener('input', () => renderHistory(lastHistory))
$('#hfClear').addEventListener('click', () => { $('#hfQ').value = ''; ['#hfP', '#hfS', '#hfM', '#hfR'].forEach((s) => ($(s).value = 'all')); renderHistory(lastHistory) })
function renderHistory(h) {
  lastHistory = h
  const today = new Date().toDateString()
  const spoken = h.filter((x) => x.status === 'spoken' && new Date(x.ts).toDateString() === today)
  $('#sCount').textContent = spoken.length
  $('#sSum').textContent = money(spoken.reduce((a, x) => a + x.amount, 0))
  const shown = h.filter(matchFilters)
  $('#histEmpty').hidden = shown.length > 0
  $('#histEmpty').textContent = h.length ? 'Ningún pago coincide con los filtros.' : 'Aún no hay pagos. Cuando llegue el primero aparecerá aquí.'
  $('#histCount').textContent = h.length ? `Mostrando ${shown.length} de ${h.length}${h.length >= 200 ? ' (se guardan los últimos 200)' : ''}` : ''
  const L = { spoken: 'Sonó', ignored: 'No sonó', error: 'Error' }
  $('#hist').innerHTML = shown.map((x) => `<tr><td class="nowrap">${fmtDate(x.ts)}</td><td><b>${money(x.amount)}</b></td><td>${esc(x.payer) || '—'}</td><td>${esc(METHOD[x.method] || '—')}</td><td><small>${esc(routeLabel(x))}</small></td><td><span class="tag ${x.status}">${L[x.status]}</span>${x.reason ? ` <small>${esc(x.reason)}</small>` : ''}</td></tr>`).join('')
}
$('#simBtn').addEventListener('click', (e) => busy(e.target, async () => {
  const r = await api('POST', '/api/test/simulate', { amount: $('#simAmount').value, payer: $('#simPayer').value, method: $('#simMethod').value })
  out('#testOut', r.action === 'speak' ? 'Suena: «' + r.text + '»' : 'No suena: ' + r.reason); load()
}))
const lastEmail = (speak) => (e) => busy(e.target, async () => {
  try {
    const r = await api('POST', '/api/test/last-email', { speak })
    const K = { venta: 'Nequi Negocios', recibido: 'cuenta personal' }
    out('#testOut', r.results.map((x) => [
      `${new Date(x.date).toLocaleString('es-CO')} · ${x.subject}${cfg.mails.length > 1 ? ' · ' + x.cuenta : ''}`,
      `  Verificación: ${x.verificacion.ok ? '✔' : '✘'} ${x.verificacion.why}`,
      x.pago ? `  Pago (${K[x.pago.kind]}): ${money(x.pago.amount)} · ${x.pago.payer || 'sin nombre'} · ${x.pago.approved ? 'confirmado' : 'NO aprobado'}` : '  No es un aviso de dinero recibido',
      x.texto ? `  Diría: «${x.texto}»` : '',
      x.pago ? `  Decisión: ${x.decision === 'speak' ? 'sonaría' : 'no sonaría'}${x.motivo ? ' (' + x.motivo + ')' : ''}` : '',
    ].filter(Boolean).join('\n')).join('\n\n'))
    if (speak) load()
  } catch (err) { out('#testOut', '✘ ' + err.message, false) }
})
$('#lastBtn').addEventListener('click', lastEmail(false))
$('#lastSpeakBtn').addEventListener('click', lastEmail(true))
$('#voiceTest').addEventListener('click', (e) => busy(e.target, async () => {
  const r = await api('POST', '/api/voice/test', { voice: collect($('#voz')).voice }); flags.set('voz'); renderOnboarding(); out('#voiceOut', 'Dijo: «' + r.text + '»')
}))
$('#pinSave').addEventListener('click', (e) => busy(e.target, async () => { await save({ adminPin: $('#newPin').value }, 'PIN actualizado ✓'); $('#newPin').value = '' }))

// ── Primeros pasos ──────────────────────────────────────────────────────
const STEPS = [
  { id: 'correo', req: true, tab: 'correo', title: 'Conecta tu correo', desc: 'Para que {producto} se entere de cada pago.', done: () => Object.values(lastStatus?.accounts ?? {}).some((a) => a.state === 'connected') },
  { id: 'voz', req: true, tab: 'voz', title: 'Elige la voz y escúchala', desc: 'Pulsa «Probar voz» y ajusta el volumen.', done: () => flags.get('voz') || lastHistory.some((h) => h.status === 'spoken') },
  { id: 'prueba', req: true, tab: 'estado', title: 'Haz un pago de prueba', desc: 'Pulsa «Simular pago» en Inicio. Debe sonar.', done: () => lastHistory.some((h) => h.status === 'spoken') },
  { id: 'celular', req: false, tab: 'celular', title: 'Avisos de Nequi a Nequi (opcional)', desc: 'Solo si te envían plata de Nequi a tu Nequi personal.', done: () => !!lastPhone?.log?.some((x) => x.via !== 'prueba') },
  { id: 'marca', req: false, tab: 'diseno', title: 'Pon tu marca (opcional)', desc: 'Tu nombre, logo y colores.', done: () => cfg.ui.businessName !== 'Mi negocio' || cfg.ui.hasLogo },
]
function renderOnboarding() {
  if (!cfg) return
  const req = STEPS.filter((s) => s.req), done = STEPS.filter((s) => s.done())
  const reqDone = req.filter((s) => s.done()).length
  const all = reqDone === req.length
  $('#onboard').hidden = flags.get('obHidden') && !flags.get('obShow')
  $('#obCount').textContent = `· ${reqDone} de ${req.length} obligatorios`
  $('#obBar').style.width = Math.round((done.length / STEPS.length) * 100) + '%'
  $('#obLead').textContent = all ? '¡Listo! Ya está funcionando. Los pasos opcionales te ayudan a sacarle más provecho.' : fmt('Sigue estos pasos y en pocos minutos tu parlante estará anunciando pagos.')
  $('#obList').innerHTML = STEPS.map((s) => `<div class="check ${s.done() ? 'done' : ''}"><span class="mark" aria-hidden="true">✓</span><div class="t"><b>${esc(s.title)}</b><span>${esc(fmt(s.desc))}</span></div><div class="acts">${tut(s.id) && cfg.ui.tutorials ? `<button class="btn secondary sm" data-video="${s.id}">▶ Video</button>` : ''}<button class="btn ${s.done() ? 'secondary' : ''} sm" data-go="${s.tab}">${s.done() ? 'Revisar' : 'Ir'}</button></div></div>`).join('')
}
$('#obList').addEventListener('click', (e) => { const b = e.target.closest('[data-go]'); if (b) go(b.dataset.go) })
$('#obHide').addEventListener('click', () => { flags.set('obHidden'); flags.set('obShow', false); renderOnboarding(); toast('Guía oculta. La puedes volver a mostrar en Ayuda.') })
$('#obShow').addEventListener('click', () => { flags.set('obHidden', false); flags.set('obShow', true); renderOnboarding(); go('estado') })

// ── Ayuda y soporte ─────────────────────────────────────────────────────
function renderHelp() {
  $('#faq').innerHTML = H.faq.map((f) => `<details class="faq"><summary>${esc(fmt(f.q))}</summary><p>${esc(fmt(f.a))}</p></details>`).join('')
  renderVideoGrid()
}
function renderSupport() {
  const wa = cfg.ui.supportWhatsapp
  const b = $('#supportBtn'); b.hidden = !wa
  if (wa) b.href = `https://wa.me/${wa}?text=${encodeURIComponent(`Hola, necesito ayuda con ${pn()} (v${lastUpdate?.current ?? '?'}). Estado: ${$('#pill').textContent}.`)}`
  $('#supportInfo').textContent = cfg.ui.supportText || ''
  $('#supportText').textContent = wa ? 'Escríbenos por WhatsApp y cuéntanos qué pasa. Te enviamos tu versión y el estado para ayudarte más rápido.' : 'Revisa los videos y las preguntas de arriba. Si sigues con dudas, contacta a quien te instaló el programa.'
}

// ── Apariencia: subir logo y favicon ────────────────────────────────────
async function toDataUrl(file, max) {
  if (/icon|\.ico$/i.test(file.type + file.name)) return await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(file) })
  const bmp = await createImageBitmap(file)
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height))
  const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(bmp.width * k)); c.height = Math.max(1, Math.round(bmp.height * k))
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height)
  const webp = c.toDataURL('image/webp', 0.92)
  return webp.startsWith('data:image/webp') ? webp : c.toDataURL('image/png')
}
const uploader = (kind, max) => async (e) => {
  const f = e.target.files[0]; if (!f) return
  try { await api('POST', '/api/brand/upload', { kind, dataUrl: await toDataUrl(f, max) }); toast(kind === 'logo' ? 'Logo guardado ✓' : 'Favicon guardado ✓'); await load(true) } catch (err) { toast(err.message) }
  e.target.value = ''
}
$('#logoFile').addEventListener('change', uploader('logo', 512))
$('#favFile').addEventListener('change', uploader('favicon', 256))
const remover = (kind) => async () => { await api('POST', '/api/brand/remove', { kind }); toast('Quitado'); await load(true) }
$('#logoDel').addEventListener('click', remover('logo'))
$('#favDel').addEventListener('click', remover('favicon'))

// ── Actualizaciones ─────────────────────────────────────────────────────
async function loadUpdate() {
  const s = lastUpdate = await api('GET', '/api/update')
  $('#uCurrent').textContent = 'v' + s.current
  $('#uLatest').textContent = s.latest ? 'v' + s.latest.version : '–'
  $('#uChecked').textContent = s.checkedAt ? new Date(s.checkedAt).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' }) : '–'
  $('#uNotes').textContent = s.available ? (s.latest.notes ? 'Novedades: ' + s.latest.notes : 'Hay una versión nueva.') : s.latest ? 'Estás al día ✓' : ''
  $('#uApply').hidden = !(s.available && s.phase === 'idle')
  $('#updBadge').hidden = !s.available
  $('#verText').textContent = `${pn()} v${s.current}`
  const when = fmtDate
  const lines = [
    { checking: 'Buscando…', downloading: 'Descargando y verificando…', restarting: s.supervised ? 'Reiniciando… esta página se recargará sola.' : 'Listo. Cierra y vuelve a abrir el programa para terminar.' }[s.phase],
    s.error,
    s.last?.rolledBack && 'La versión ' + s.last.rolledBack + ' no arrancó bien y se volvió a la anterior (' + when(s.last.at) + ').',
    s.last?.updated && !s.last.rolledBack && 'Última actualización: v' + s.last.updated + ' (' + when(s.last.at) + ').',
  ].filter(Boolean)
  const m = $('#uMsg'); m.textContent = lines.join('\n'); m.className = lines.length ? 'out show' : 'out'; m.style.color = s.error ? 'var(--bad)' : ''
  return s
}
function reloadWhenBack() {
  let wentDown = false
  const t = setInterval(async () => { try { await fetch('/api/public', { cache: 'no-store' }); if (wentDown) { clearInterval(t); location.reload() } } catch { wentDown = true } }, 1500)
  setTimeout(() => clearInterval(t), 90_000)
}
$('#uCheck').addEventListener('click', (e) => busy(e.target, async () => { await api('POST', '/api/update/check'); await loadUpdate() }))
$('#uApply').addEventListener('click', (e) => busy(e.target, async () => {
  if (!confirm('El programa se reiniciará unos segundos y no sonará durante ese tiempo. ¿Actualizar ahora?')) return
  const s = await api('POST', '/api/update/apply'); await loadUpdate(); if (s.supervised) reloadWhenBack()
}))

// ── Celular ─────────────────────────────────────────────────────────────
async function loadPhone() {
  const s = lastPhone = await api('GET', '/api/phone/setup')
  $('#qrCloud').innerHTML = s.cloudQr; $('#qrWifi').innerHTML = s.wifiQr; $('#qrBody').innerHTML = s.bodyQr
  $('#phoneCloud').textContent = s.cloudUrl; $('#phoneCloudIos').textContent = s.cloudUrl; $('#phoneWifi').textContent = s.wifiUrl; $('#phoneBody').textContent = s.body
  const tag = $('#cloudTag'); tag.textContent = s.cloud ? 'activa' : 'apagada (enciéndela arriba)'; tag.style.setProperty('--c', s.cloud ? 'var(--ok)' : 'var(--warn)')
  $('#qrCloud').style.opacity = s.cloud ? 1 : 0.35
  const R = { connected: ['Escuchando', 'var(--ok)'], connecting: ['Conectando…', 'var(--warn)'], error: ['Error: ' + (s.relay.error || ''), 'var(--bad)'], off: [s.enabled ? 'Apagado' : 'Avisos del celular apagados', 'var(--muted)'] }[s.relay.state] || ['', '']
  $('#relayState').textContent = R[0]; $('#relayState').style.color = R[1]
  $('#phoneEmpty').hidden = s.log.length > 0
  $('#phoneLog').innerHTML = s.log.map((x) => `<tr><td class="nowrap">${fmtDate(x.ts)}</td><td><small>${esc(x.app)}${x.via ? ' · por ' + esc(x.via) : ''}</small><br>${esc(x.title)} ${esc(x.text)}</td><td>${esc(x.result)}</td></tr>`).join('')
  renderOnboarding()
}
$$('[data-copy]').forEach((b) => b.addEventListener('click', async () => { await navigator.clipboard.writeText($('#' + b.dataset.copy).textContent); toast('Copiado ✓') }))
$('#phoneTest').addEventListener('click', (e) => busy(e.target, async () => { const r = await api('POST', '/api/phone/test'); toast(r.result); loadPhone(); load() }))
const regen = (path, msg) => async (e) => { e.preventDefault(); if (!confirm('El celular dejará de funcionar hasta que pongas la nueva URL en MacroDroid. ¿Continuar?')) return; await api('POST', path); loadPhone(); toast(msg) }
$('#newKey').addEventListener('click', regen('/api/phone/new-key', 'Clave nueva generada ✓'))
$('#newTopic').addEventListener('click', regen('/api/phone/new-topic', 'Tema nuevo generado ✓'))

// ── Monitoreo ───────────────────────────────────────────────────────────
function renderMonitor(s) {
  const T = !s.configured ? ['Sin configurar (faltan el ID y el token)', 'var(--muted)'] : s.state === 'ok' ? ['Enviando · última señal ' + new Date(s.at).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' }), 'var(--ok)'] : s.state === 'error' ? ['Error: ' + s.error, 'var(--bad)'] : ['Apagado o esperando la primera señal', 'var(--muted)']
  $('#monState').textContent = T[0]; $('#monState').style.color = T[1]
}
$('#monTest').addEventListener('click', (e) => busy(e.target, async () => { renderMonitor(await api('POST', '/api/monitor/test')); toast('Señal enviada') }))

// ── Carga y entrada ─────────────────────────────────────────────────────
async function load(forceUi) {
  const s = await api('GET', '/api/state')
  cfg = s.config
  if (!formDirty) { fill(cfg); applyUi(cfg.ui) } else { $('#paused').checked = cfg.paused; if (forceUi) applyUi(cfg.ui) }
  renderStatus(s.status)
  renderHistory(s.history)
  renderOnboarding()
  renderSupport()
}
function showLogin() { clearInterval(polling); $('#app').hidden = true; $('#login').hidden = false; $('#pin').focus() }
$('#loginBtn').addEventListener('click', async () => { try { await api('POST', '/api/login', { pin: $('#pin').value }); location.reload() } catch (e) { toast(e.message) } })
$('#pin').addEventListener('keydown', (e) => e.key === 'Enter' && $('#loginBtn').click())

async function init() {
  const pub = await api('GET', '/api/public')
  cfg = { ui: pub.ui }
  applyUi(pub.ui)
  if (pub.needsLogin) { try { await api('GET', '/api/state') } catch { return showLogin() } }
  $('#app').hidden = false
  renderTips()
  renderHelp()
  api('GET', '/api/voices').then((vs) => { $('#voiceSel').innerHTML = vs.map((v) => `<option value="${esc(v.id)}">${esc(v.label)}</option>`).join(''); if (cfg.voice) $('#voiceSel').value = cfg.voice.voice })
  await load()
  const tab = location.hash.slice(1); if (tab) go(tab)
  loadPhone().catch(() => {})
  loadUpdate().then(renderSupport).catch(() => {})
  api('GET', '/api/monitor').then(renderMonitor).catch(() => {})
  let tick = 0
  polling = setInterval(() => {
    if (document.hidden) return
    load().catch(() => {})
    if ($('#celular').classList.contains('on')) loadPhone().catch(() => {})
    if ($('#seg').classList.contains('on')) api('GET', '/api/monitor').then(renderMonitor).catch(() => {})
    if ($('#actualizar').classList.contains('on') || ++tick % 10 === 0) loadUpdate().catch(() => {})
  }, 3000)
}
init()
