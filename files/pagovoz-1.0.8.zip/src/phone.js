import { createHash } from 'node:crypto'
import { networkInterfaces } from 'node:os'

import { toAmount } from './parse.js'

// Notificación de la app Nequi para envíos Nequi → Nequi (no llega correo):
//   título "Envío" · texto "ANA GOMEZ te envió 500, ¡lo mejor!"
const SENT_RE = /^\s*(?:Env[ií]o\s*[:·-]?\s*)?(.+?)\s+te\s+envi[oó]\s+\$?\s*(\d[\d.,]*)/i

/** Lo que MacroDroid pone en el cuerpo, una cosa por línea (ver `PHONE_BODY`). */
export const PHONE_BODY = '{not_app_package}\n{not_timestamp}\n{not_title}\n{notification}'

const pick = (o, ...keys) => {
  for (const k of keys) if (o?.[k] !== undefined && String(o[k]).trim()) return String(o[k]).trim()
  return ''
}

/** Acepta el texto plano de MacroDroid o el JSON de otras apps reenviadoras. */
export function normalizePhone(raw) {
  let body
  try {
    body = JSON.parse(raw)
  } catch {}
  if (body && typeof body === 'object') {
    return {
      app: pick(body, 'package', 'packageName', 'not_app_package'),
      at: Number(pick(body, 'timestamp', 'not_timestamp', 'postedAt', 'post_time')) || Date.parse(pick(body, 'postedAt', 'post_time')) || null,
      title: pick(body, 'title', 'not_title'),
      text: pick(body, 'bigText', 'big_text', 'text', 'notification', 'content', 'message'),
    }
  }
  const [app = '', at = '', title = '', ...rest] = String(raw).replace(/\r/g, '').split('\n')
  return { app: app.trim(), at: Number(at.trim()) || null, title: title.trim(), text: rest.join(' ').trim() }
}

export function parsePhone(n) {
  for (const line of [n.text, `${n.title} ${n.text}`]) {
    const m = SENT_RE.exec(String(line).replace(/\s+/g, ' '))
    const amount = toAmount(m?.[2]?.replace(/[.,]$/, '') ?? '')
    if (amount) return { amount, payer: m[1].trim(), approved: true, kind: 'nequi', method: 'nequi' }
  }
  return null
}

const recent = new Map()
/** La misma notificación reenviada (reintento, o Android que la vuelve a publicar) suena una sola vez. */
export function isRepeat(n, windowMs = 90_000) {
  const now = Date.now()
  for (const [k, t] of recent) if (now - t > 10 * 60_000) recent.delete(k)
  const key = createHash('sha1').update(`${n.app}|${n.at ?? ''}|${n.text}`).digest('hex')
  const seen = recent.get(key)
  recent.set(key, now)
  // Con hora de la notificación, misma hora = misma notificación. Sin ella, solo dentro de la ventana.
  return seen !== undefined && (n.at !== null || now - seen < windowMs)
}

/** IP del equipo en la red local (WiFi o cable), para armar la dirección que usa el celular. */
export function lanAddress() {
  const all = Object.values(networkInterfaces())
    .flat()
    .filter((i) => i && i.family === 'IPv4' && !i.internal)
    .map((i) => i.address)
  return all.find((a) => a.startsWith('192.168.')) ?? all.find((a) => a.startsWith('10.') || a.startsWith('172.')) ?? all[0] ?? '127.0.0.1'
}
