import { convert } from 'html-to-text'
import { simpleParser } from 'mailparser'

import { authResultsOf, parsePayment, verifySender } from './parse.js'
import { amountToSpanish, niceName } from './spanish.js'
import { addHistory, getConfig, getState, saveHistory, setState } from './store.js'

const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Bogota' })

/** Conteo del día por ruta (lo lee el monitor). Se reinicia solo al cambiar de día. */
export function bumpStats(entry) {
  const d = today()
  const s = getState().stats?.date === d ? getState().stats : { date: d, routes: {}, spoken: 0, ignored: 0, error: 0 }
  if (entry.status === 'spoken') s.routes[entry.route] = (s.routes[entry.route] ?? 0) + 1
  s[entry.status === 'spoken' ? 'spoken' : entry.status === 'error' ? 'error' : 'ignored']++
  setState({ stats: s })
}
import { enqueue, speak } from './voice.js'

export async function analyzeMail(source, cfg) {
  const m = await simpleParser(source)
  const from = m.from?.value?.[0]?.address ?? ''
  // Algunos correos de Nequi (p. ej. "¡Recibiste plata por Bre-B!") solo traen HTML.
  const text = m.text || (m.html ? convert(m.html, { wordwrap: false, selectors: [{ selector: 'img', format: 'skip' }, { selector: 'a', options: { ignoreHref: true } }] }) : '')
  return {
    id: m.messageId ?? '',
    date: m.date?.getTime() ?? Date.now(),
    from,
    subject: m.subject ?? '',
    auth: verifySender(from, authResultsOf(source), cfg.senders, cfg.requireDkim),
    pay: parsePayment(text, m.subject ?? ''),
  }
}

export const METHOD_LABELS = { llave: 'por llave', qr: 'por QR', nequi: 'por Nequi' }

export function buildText(v, { amount, payer, method }) {
  const name = v.sayName ? niceName(payer, v.firstNameOnly) : ''
  const how = v.sayMethod === false ? '' : (v.methodLabels?.[method] ?? METHOD_LABELS[method] ?? '')
  return v.template
    .replaceAll('{monto}', amountToSpanish(amount))
    .replaceAll('{pagador}', name ? `de ${name}` : '')
    .replaceAll('{medio}', how)
    .replace(/\s+/g, ' ')
    .trim()
}

/** Qué hacer con un pago. Función pura: toda la lógica de "solo suena si está confirmado" vive aquí. */
export function decide(cfg, a, { now = Date.now(), ignoreAge = false } = {}) {
  if (!a.pay) return { action: 'skip' }
  if (cfg.sources[a.pay.kind] === false) return { action: 'ignore', reason: a.pay.kind === 'venta' ? 'avisos de Nequi Negocios apagados' : 'avisos de cuenta personal apagados' }
  if (!a.pay.approved) return { action: 'ignore', reason: 'estado distinto de Aprobada' }
  if (!a.auth.ok) return { action: 'ignore', reason: a.auth.why }
  if (cfg.paused) return { action: 'ignore', reason: 'en pausa' }
  if (!ignoreAge && now - a.date > cfg.maxAgeMin * 60_000) return { action: 'ignore', reason: 'correo antiguo' }
  const { enabled, amount } = cfg.rules.silenceAbove
  if (enabled && a.pay.amount >= amount) return { action: 'ignore', reason: `monto ≥ ${amount.toLocaleString('es-CO')} (silencio)` }
  return { action: 'speak' }
}

export function handlePayment(a, source, opts) {
  const cfg = getConfig()
  const d = decide(cfg, a, opts)
  if (d.action === 'skip' || opts?.dryRun) return { ...d }
  const entry = { ts: Date.now(), source, route: a.route ?? source, method: a.pay.method ?? '', account: a.account, kind: a.pay.kind, amount: a.pay.amount, payer: a.pay.payer, status: d.action === 'speak' ? 'spoken' : 'ignored', reason: d.reason ?? '' }
  if (d.action === 'speak') {
    entry.text = buildText(cfg.voice, a.pay)
    enqueue(() =>
      speak(cfg.voice, entry.text).catch((e) => {
        entry.status = 'error'
        entry.reason = e.message.slice(0, 120)
        saveHistory()
        bumpStats({ ...entry, status: 'error' })
      }),
    )
  }
  addHistory(entry)
  bumpStats(entry)
  return { ...d, entry }
}

export async function processMail(source, account, route = 'push') {
  const a = await analyzeMail(source, getConfig())
  a.account = account?.label || account?.user
  a.route = `correo:${route}`
  if (!a.pay) return
  const { seen } = getState()
  if (a.id && seen.includes(a.id)) return
  if (a.id) setState({ seen: [...seen, a.id].slice(-500) })
  handlePayment(a, 'correo')
}
