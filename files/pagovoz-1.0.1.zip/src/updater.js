import { createHash, createPublicKey, verify } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'

import { lockHash } from './lockhash.js'
import { paths } from './update-apply.js'
import { readZip } from './zip.js'

const MAX_BYTES = 200 * 1024 * 1024
const FILE_RE = /^pagovoz-[\w.-]+\.zip$/
const HEX = /^[a-f0-9]{64}$/
const readJson = (file) => {
  try {
    return JSON.parse(readFileSync(file, 'utf8'))
  } catch {
    return null
  }
}

export function semverGt(a, b) {
  const parts = (v) => String(v).split('-')[0].split('.').map((n) => Number(n) || 0)
  const [x, y] = [parts(a), parts(b)]
  for (let i = 0; i < 3; i++) if ((x[i] ?? 0) !== (y[i] ?? 0)) return (x[i] ?? 0) > (y[i] ?? 0)
  return false
}

const checkFile = (f, what) => {
  if (!f || !FILE_RE.test(f.file) || !HEX.test(f.sha256) || !Number.isInteger(f.size) || f.size < 1 || f.size > MAX_BYTES) throw new Error(`manifiesto inválido (${what})`)
}

/** Verifica la FIRMA antes de confiar en nada del contenido. */
export function verifyManifest(text, publicKeyPem) {
  let outer
  try {
    outer = JSON.parse(text)
  } catch {
    throw new Error('manifiesto ilegible')
  }
  if (typeof outer?.payload !== 'string' || typeof outer?.signature !== 'string') throw new Error('manifiesto inválido')
  if (!verify(null, Buffer.from(outer.payload), createPublicKey(publicKeyPem), Buffer.from(outer.signature, 'base64'))) {
    throw new Error('la firma no es válida: actualización rechazada')
  }
  const p = JSON.parse(outer.payload)
  if (!/^\d+\.\d+\.\d+$/.test(p.version) || !HEX.test(p.lock)) throw new Error('manifiesto inválido (versión)')
  checkFile(p.small, 'paquete')
  if (p.deps) checkFile(p.deps, 'librerías')
  return { version: p.version, published: p.published, notes: String(p.notes ?? '').slice(0, 600), lock: p.lock, small: p.small, deps: p.deps }
}

/**
 * `getSettings()` → { auto, time:'HH:MM' }. `restart()` se llama solo si hay un supervisor que vuelva a abrir la app.
 */
export function createUpdater({ root, dataDir, baseUrl, publicKey, getSettings, isBusy = () => false, supervised = false, restart = () => process.exit(0), fetchImpl = fetch, now = () => new Date(), log = console.error }) {
  const P = paths(dataDir)
  let state = { phase: 'idle', latest: null, checkedAt: null, error: null }
  let autoDay = ''
  const current = () => JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')).version
  const failed = () => readJson(P.failed) ?? []
  const available = () => !!state.latest && semverGt(state.latest.version, current()) && !failed().includes(state.latest.version)

  async function get(url, { binary = false, timeout = 20_000 } = {}) {
    const res = await fetchImpl(url, { signal: AbortSignal.timeout(timeout), headers: { 'User-Agent': 'PagoVoz-updater' } })
    if (!res.ok) throw new Error(`el servidor respondió ${res.status}`)
    return binary ? Buffer.from(await res.arrayBuffer()) : res.text()
  }

  async function download(f) {
    const buf = await get(`${baseUrl}/files/${f.file}`, { binary: true, timeout: 180_000 })
    if (buf.length !== f.size) throw new Error(`${f.file}: tamaño distinto al anunciado`)
    if (createHash('sha256').update(buf).digest('hex') !== f.sha256) throw new Error(`${f.file}: la huella no coincide, descarga rechazada`)
    return buf
  }

  function status() {
    const l = state.latest
    return {
      current: current(),
      latest: l ? { version: l.version, notes: l.notes, published: l.published } : null,
      available: available(),
      phase: state.phase,
      error: state.error,
      checkedAt: state.checkedAt,
      supervised,
      last: readJson(P.last),
      failed: failed(),
      pending: readJson(P.pending)?.version ?? null,
    }
  }

  async function check() {
    if (state.phase !== 'idle') return status()
    state = { ...state, phase: 'checking', error: null }
    try {
      const latest = verifyManifest(await get(`${baseUrl}/latest.json?_=${Date.now()}`), publicKey)
      state = { phase: 'idle', latest, checkedAt: Date.now(), error: null }
    } catch (e) {
      state = { ...state, phase: 'idle', checkedAt: Date.now(), error: `No se pudo revisar: ${e.message}` }
    }
    return status()
  }

  async function apply() {
    if (state.phase !== 'idle') return status()
    if (!available()) throw new Error('No hay una actualización disponible')
    const p = state.latest
    state = { ...state, phase: 'downloading', error: null }
    try {
      const needDeps = lockHash(readFileSync(join(root, 'package-lock.json'), 'utf8')) !== p.lock
      if (needDeps && !p.deps) throw new Error('esta versión cambió las librerías y requiere reinstalar el paquete completo')
      const entries = readZip(await download(p.small))
      const deps = needDeps ? readZip(await download(p.deps)) : []

      const okName = (n) => n.startsWith('src/') || n.startsWith('public/') || n === 'package.json' || n === 'package-lock.json'
      if (entries.some((e) => !okName(e.name))) throw new Error('el paquete trae archivos no permitidos')
      if (deps.some((e) => !e.name.startsWith('node_modules/'))) throw new Error('el paquete de librerías trae archivos no permitidos')
      const pkg = entries.find((e) => e.name === 'package.json')
      if (!pkg || JSON.parse(pkg.data.toString()).version !== p.version) throw new Error('la versión del paquete no coincide con la anunciada')
      if (!entries.some((e) => e.name === 'src/boot.js' || e.name === 'src/server.js')) throw new Error('el paquete no trae la aplicación')

      rmSync(P.stage, { recursive: true, force: true })
      for (const e of [...entries, ...deps]) {
        const dest = join(P.stage, e.name)
        mkdirSync(dirname(dest), { recursive: true })
        writeFileSync(dest, e.data)
      }
      writeFileSync(P.pending, JSON.stringify({ state: 'staged', version: p.version, from: current(), at: Date.now() }))
      state = { ...state, phase: 'restarting' }
      if (supervised) setTimeout(restart, 700).unref?.()
      return status()
    } catch (e) {
      rmSync(P.stage, { recursive: true, force: true })
      rmSync(P.pending, { force: true })
      state = { ...state, phase: 'idle', error: `No se pudo actualizar: ${e.message}` }
      throw new Error(state.error)
    }
  }

  /** Cada minuto: si el usuario eligió actualización automática y ya es la hora, actualiza (solo si no está sonando). */
  async function tick() {
    const s = getSettings()
    if (!s.auto || state.phase !== 'idle') return
    const n = now()
    const [h, m] = s.time.split(':').map(Number)
    const due = new Date(n)
    due.setHours(h, m, 0, 0)
    const minutes = (n - due) / 60_000
    if (minutes < 0 || minutes > 180 || autoDay === n.toDateString() || isBusy()) return
    await check()
    if (state.error) return // sin internet: reintenta el minuto siguiente
    autoDay = n.toDateString()
    if (available()) await apply().catch((e) => log('auto-actualización:', e.message))
  }

  /** La app lleva 45 s sana: la actualización queda confirmada y ya no se deshace. */
  function markHealthy() {
    const p = readJson(P.pending)
    if (p?.state !== 'applied') return
    writeFileSync(P.last, JSON.stringify({ updated: p.version, from: p.from, at: Date.now() }))
    rmSync(P.pending, { force: true })
  }

  function start() {
    const jitter = 20_000 + Math.random() * 280_000 // que los negocios no consulten todos a la vez
    setTimeout(() => check().catch(() => {}), jitter).unref?.()
    setInterval(() => check().catch(() => {}), 6 * 3600_000).unref?.()
    setInterval(() => tick().catch((e) => log('actualizador:', e.message)), 60_000).unref?.()
  }

  return { status, check, apply, tick, markHealthy, start }
}
